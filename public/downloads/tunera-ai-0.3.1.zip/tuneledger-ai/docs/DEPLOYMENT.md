# Deployment handoff

TuneLedger's portfolio publication and public CPU Space were approved by the user.
Destinations: https://jacobroutzong.dev/projects/tuneledger/ and
https://huggingface.co/spaces/jacobroutzong/tuneledger.
The Space uses Docker to install the hash-pinned Gradio dependency lock directly.
The hosted Gradio builder mounts only requirements.txt and cannot resolve a
relative lock include. GPU training and HF Jobs acceptance remain pending.

## Colab first

`deployment/colab-mcp.example.json` follows Google's official setup example.
Configure it in a compatible client, connect the Colab session, select GPU,
mount Drive and transfer the source archive or a pinned Git checkout. These
connection/consent actions cannot be performed through this chat's available
tools. Once connected, run:

```bash
python scripts/run_colab.py --persistent /content/drive/MyDrive/TuneLedger --run qwen3-smoke-001
# After allocation/quota approval, in the attached runtime:
python scripts/run_colab.py --persistent /content/drive/MyDrive/TuneLedger --run qwen3-smoke-001 --execute
```

This installs the locked environment, checks CUDA, runs CPU checks, prepares
synthetic splits, trains two optimizer steps and evaluates base/adapter in
separate processes. A real run requires both `--config` and `--data`; there is
no fallback to synthetic data. `--resume latest` recovers a complete checkpoint.
The existing notebook remains available as a fallback.

## HF Jobs alternative

Build `deployment/Dockerfile.training` from the repository root on a Linux Docker
builder. The CUDA runtime is resolved by the existing GPU lock; the target host
must provide a compatible NVIDIA driver. Building/pushing the image and GPU
acceptance have not been executed. Record and use the resulting registry digest.

```bash
docker build -f deployment/Dockerfile.training -t tuneledger-training:0.3.1 .
```

Create a reviewed JSON job specification with these fields. The image digest
and dataset revision below are placeholders and must be replaced:

```json
{
  "image": "YOUR_REGISTRY/tuneledger-training@sha256:REPLACE_WITH_64_HEX_DIGEST",
  "dataset_repo": "jacobroutzong/tuneledger-private-data",
  "dataset_revision": "REPLACE_WITH_40_HEX_COMMIT",
  "artifact_repo": "jacobroutzong/tuneledger-run-001",
  "run_name": "qwen3-smoke-001",
  "flavor": "a10g-small",
  "timeout_seconds": 1800,
  "smoke": true,
  "config": {"target": "qwen3-4b", "model_id": "Qwen/Qwen3-4B", "revision": "1cfa9a7208912126459214e8b04321603b3df60c"}
}
```

The dataset repository needs `train.jsonl`, `validation.jsonl`, `test.jsonl` at
its root; upload licensed data privately. Each artifact repository belongs to
one experiment and must be private. Existing runs require `resume_revision` set
to an immutable artifact commit. The worker validates inputs, restores and checks
checkpoints, trains, evaluates and saves private results.

```bash
tuneledger launch --provider hf-jobs --job-spec job.json --plan-output artifacts/job-plan.json
# Only after approval of flavor, current price and timeout:
tuneledger launch --provider hf-jobs --job-spec job.json --execute --approve-cost --plan-output artifacts/job-receipt.json
tuneledger job status JOB_ID
tuneledger job logs JOB_ID
tuneledger job cancel JOB_ID --execute
tuneledger restore --repo jacobroutzong/tuneledger-run-001 --revision FULL_COMMIT --output artifacts/restored-run --execute
```

The account is verified before mutation. No token literal belongs in the spec;
the existing HF credential store supplies the SDK secret channel. A live remote
container, timeout, uploads and GPU recovery still need acceptance validation.

## Model releases, Space and portfolio

Keep model release staging separate from raw private experiment storage. The
existing `publish` command uses an adapter/tokenizer/config/metadata allowlist
and rejects smoke-only runs. It has no authority to assert model improvements.
Do not publish user-supplied metadata or weights without reviewing their terms.

```bash
tuneledger stage-space --output artifacts/space-release
# Optional measured comparison, after inspecting its aggregate metrics:
tuneledger stage-space --output artifacts/space-release-with-results --comparison RUN/evaluation/comparison.json
```

The staged Gradio Space runs on CPU, shows availability and aggregate evaluation
data, and contacts an explicitly configured inference gateway. The Space is not
a training GPU and cannot reach a laptop's localhost. Configure
`TUNELEDGER_ENDPOINT`, `TUNELEDGER_OLLAMA_MODEL` and optional
`TUNELEDGER_ENDPOINT_TOKEN` in provider secrets. It sends each request independently
and bounds queue, concurrency and response tokens. No inference gateway is
currently deployed or verified.

After approval, create `jacobroutzong/tuneledger` with CPU hardware and upload
only the staged directory. The portfolio repository is
`jacobhroutzong/portfolio-website`. Add a page at `/projects/tuneledger/` using
`deployment/portfolio-embed.html`, and link it from both the homepage Selected
projects section and Projects listing. The integration uses the existing site's
layout and its connected Cloudflare Pages deployment. No DNS or hosting settings
need modification; the production build follows main.
