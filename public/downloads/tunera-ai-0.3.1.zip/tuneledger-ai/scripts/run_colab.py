"""Run from official Colab MCP or a notebook cell after runtime/Drive consent.

Usage: python scripts/run_colab.py --persistent /content/drive/MyDrive/TuneLedger --run trial-001 --execute
Without --execute, print a plan without installing packages or consuming GPU.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--persistent', required=True, type=Path)
    p.add_argument('--run', required=True)
    p.add_argument('--execute', action='store_true')
    p.add_argument('--config', type=Path)
    p.add_argument('--data', type=Path)
    p.add_argument('--resume')
    args = p.parse_args()
    if Path(args.run).name != args.run or args.run in ('.', '..'):
        p.error('Use a single directory name for --run')
    if bool(args.config) != bool(args.data):
        p.error('Long runs require both --config and --data')
    root = Path(__file__).resolve().parents[1]
    python = str(root / '.venv/bin/python')
    data = args.data or args.persistent / (args.run + '-splits')
    config = args.config or root / 'configs/qwen3_4b.json'
    commands = [[sys.executable, '-m', 'pip', 'install', 'uv==0.13.0'],
        ['uv', 'sync', '--project', str(root), '--frozen', '--extra', 'gpu', '--python', '3.12'],
        [python, '-m', 'tuneledger.cli', 'gpu-info'],
        [python, '-m', 'unittest', 'discover', '-s', 'tests', '-v'],
        [python, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_official_tokenizer.py', '-v']]
    if not args.data:
        commands.append([python, '-m', 'tuneledger.cli', 'split', str(root / 'data/smoke.jsonl'), str(data)])
    pipeline = [python, '-m', 'tuneledger.cli', 'pipeline', '--config', str(config),
                '--data', str(data), '--output', str(args.persistent / args.run), '--execute']
    if not args.config:
        pipeline.append('--smoke')
    if args.resume:
        pipeline += ['--resume', args.resume]
    commands.append(pipeline)
    print(json.dumps({'commands': commands, 'execute': args.execute}, indent=2))
    if args.execute:
        if not Path('/content/drive/MyDrive').is_dir():
            p.error('Mount Google Drive in Colab before executing; artifacts must survive runtime eviction')
        for command in commands:
            env = dict(os.environ, TUNELEDGER_TOKENIZER_TEST='1') if 'test_official_tokenizer.py' in command else None
            subprocess.run(command, cwd=root, check=True, env=env)


if __name__ == '__main__':
    main()
