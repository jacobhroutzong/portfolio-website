"""Optional GGUF export; check tool/architecture compatibility before conversion."""
import shutil
import subprocess
import sys
from pathlib import Path


def export_gguf(merged_model_dir, llama_cpp_dir, output, enabled=False):
    import json
    if not enabled:
        raise ValueError("GGUF export requires explicit --enable-export")
    model, tools, out = Path(merged_model_dir), Path(llama_cpp_dir), Path(output)
    if json.loads((model/"config.json").read_text())["model_type"] != "qwen3":
        raise ValueError("Only merged Qwen3 models are eligible in Sprint 1")
    converter = tools/"convert_hf_to_gguf.py"
    quantizer = next((p for p in (tools/"build/bin/llama-quantize", tools/"build/bin/llama-quantize.exe") if p.is_file()), None)
    if not converter.is_file() or quantizer is None:
        raise ValueError("Provide an explicitly selected, built llama.cpp checkout")
    help_text = subprocess.check_output([sys.executable, str(converter), "--print-supported-models"], text=True)
    if "Qwen3ForCausalLM" not in help_text:
        raise ValueError("This converter does not advertise Qwen3 support")
    if shutil.disk_usage(out.parent).free < 20*2**30:
        raise ValueError("Need at least 20 GiB free disk for conversion intermediates")
    if out.exists() or out.with_suffix(".f16.gguf").exists():
        raise ValueError("Refusing to overwrite GGUF artifacts")
    intermediate = out.with_suffix(".f16.gguf")
    subprocess.run([sys.executable, str(converter), str(model), "--outfile", str(intermediate), "--outtype", "f16"], check=True)
    subprocess.run([str(quantizer), str(intermediate), str(out), "Q4_K_M"], check=True)
    if not out.is_file():
        raise RuntimeError("Quantizer did not produce the requested output")
    return out
