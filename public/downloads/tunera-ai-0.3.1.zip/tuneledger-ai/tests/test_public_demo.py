import json
from pathlib import Path
import runpy
import unittest

CORE = runpy.run_path(str(Path(__file__).resolve().parents[1] / 'space/demo_core.py'))


class PublicDemoTests(unittest.TestCase):
    def test_validation_uses_real_dataset_checks(self):
        result = CORE['validate_data'](CORE['EXAMPLES'])
        self.assertTrue(result['valid'])
        self.assertEqual(result['rows'], 12)
        self.assertEqual(sum(v['count'] for v in result['split_preview'].values()), 12)
        self.assertFalse(CORE['validate_data'](CORE['EXAMPLES'] + '\n' + CORE['EXAMPLES'].splitlines()[0])['valid'])

    def test_input_limits_and_strict_json(self):
        for value in ('x' * 256001, '', '{"id":"a","id":"b"}'):
            self.assertFalse(CORE['validate_data'](value)['valid'])

    def test_pinned_plan_is_configuration_only(self):
        result = CORE['plan_run']('4B', 512, 16, 100)
        self.assertEqual(result['config']['revision'], '1cfa9a7208912126459214e8b04321603b3df60c')
        self.assertEqual(result['effective_batch_size'], 4)
        self.assertIn('No compute started', result['status'])
        with self.assertRaises(ValueError):
            CORE['plan_run']('not-a-model', 512, 16, 100)

    def test_saved_output_scores_are_explicit_and_complete(self):
        rows = [json.loads(line) for line in CORE['EXAMPLES'].splitlines()]
        predictions = {r['id']: r['messages'][-1]['content'] for r in rows}
        result = CORE['score_outputs'](CORE['EXAMPLES'], json.dumps(predictions))
        self.assertEqual(result['accuracy'], 1)
        self.assertIn('no model was run', result['source'])
        predictions.pop(rows[0]['id'])
        self.assertIn('error', CORE['score_outputs'](CORE['EXAMPLES'], json.dumps(predictions)))


if __name__ == '__main__':
    unittest.main()
