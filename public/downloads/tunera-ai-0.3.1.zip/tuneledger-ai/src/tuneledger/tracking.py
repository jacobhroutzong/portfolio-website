"""Local append-only event history; no external tracking service required."""
import json
from datetime import datetime, timezone
from pathlib import Path
from .artifacts import write_json


def event(run, kind, **values):
    path = Path(run)
    path.mkdir(parents=True, exist_ok=True)
    record = {'time': datetime.now(timezone.utc).isoformat(), 'event': kind, **values}
    with (path / 'events.jsonl').open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(record, sort_keys=True, allow_nan=False) + '\n')


def list_runs(root):
    result = []
    for p in sorted(Path(root).glob('*/manifest.json')):
        record = json.loads(p.read_text(encoding='utf-8'))
        result.append({'run': p.parent.name, 'status': record.get('status'),
                       'target': record.get('config', {}).get('target'),
                       'smoke_only': record.get('smoke_only'),
                       'fingerprint': record.get('fingerprint')})
    return result


def trainer_callback(run, sync=None):
    from transformers import TrainerCallback
    from .checkpoints import seal_checkpoint

    class Callback(TrainerCallback):
        def on_log(self, args, state, control, logs=None, **kwargs):
            if state.is_world_process_zero:
                event(run, 'metrics', step=state.global_step, metrics=logs or {})

        def on_save(self, args, state, control, **kwargs):
            if state.is_world_process_zero:
                checkpoint = seal_checkpoint(Path(args.output_dir) / f'checkpoint-{state.global_step}')
                event(run, 'checkpoint', step=state.global_step, checkpoint=checkpoint.name)
                write_json(Path(run) / 'latest_checkpoint.json', {'checkpoint': checkpoint.name})
                if sync:
                    sync(Path(run))
    return Callback()
