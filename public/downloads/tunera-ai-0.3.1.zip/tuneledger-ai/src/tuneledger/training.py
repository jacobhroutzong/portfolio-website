"""Colab QLoRA orchestration with durable artifacts and explicit resume."""
import os
from dataclasses import replace
from pathlib import Path
from .artifacts import digest, environment, implementation_hash, write_json
from .datasets import load_splits
from .models import require_target, load_training_model


def gpu_info():
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU required; select a Colab GPU runtime")
    props = torch.cuda.get_device_properties(0)
    if props.major < 7:
        raise RuntimeError("Unsloth requires CUDA compute capability >= 7.0")
    return {"gpu": props.name, "total_gib": props.total_memory / 2**30,
            "free_gib": torch.cuda.mem_get_info()[0] / 2**30,
            "torch": torch.__version__, "cuda": torch.version.cuda,
            "bf16": torch.cuda.is_bf16_supported(), "capability": [props.major, props.minor]}


def encode_rows(rows, tokenizer, max_length, assistant_only):
    """Use official template's token-aligned generation masks, fail closed if absent.

    Qwen3's official template may not contain Jinja generation blocks. For that
    template, label only the final assistant suffix after proving the rendered
    generation prompt is an exact token prefix. Earlier assistant turns are
    context only. Never silently fall back to loss on user text.
    """
    encoded = []
    for row in rows:
        messages = row["messages"]
        full = tokenizer.apply_chat_template(messages, tokenize=True,
                    add_generation_prompt=False, enable_thinking=False)
        if assistant_only:
            prefix = tokenizer.apply_chat_template(messages[:-1], tokenize=True,
                    add_generation_prompt=True, enable_thinking=False)
            if full[:len(prefix)] != prefix:
                raise ValueError(f"Official template prefix mismatch for {row['id']}; cannot safely mask loss")
            labels = [-100]*len(prefix) + full[len(prefix):]
        else:
            labels = list(full)
        full, labels = full[:max_length], labels[:max_length]
        if not any(x != -100 for x in labels[1:]):
            raise ValueError(f"No assistant training tokens after truncation: {row['id']}")
        encoded.append({"input_ids": full, "attention_mask": [1]*len(full), "labels": labels})
    return encoded


class LabelCollator:
    """Right-pad without replacing precomputed assistant labels."""
    def __init__(self, pad_token_id):
        self.pad_token_id = pad_token_id

    def __call__(self, features):
        import torch
        length = max(len(f["input_ids"]) for f in features)
        return {key: torch.tensor([f[key] + [pad]*(length-len(f[key])) for f in features])
                for key, pad in (("input_ids", self.pad_token_id), ("attention_mask", 0), ("labels", -100))}


def train(config, data_dir, output_dir, resume=None, smoke=False, checkpoint_sync=None):
    require_target(config)
    splits = load_splits(data_dir)
    path = Path(output_dir).resolve()
    path.mkdir(parents=True, exist_ok=True)
    if any(path.iterdir()) and not resume and any(p.name != 'job.json' for p in path.iterdir()):
        raise ValueError("Run already exists; use a new output directory or explicit --resume")
    if smoke:
        config = replace(config, max_steps=2, save_steps=1, eval_steps=1,
                         max_length=min(config.max_length, 256), report_to="none")
    if config.report_to == "wandb" and os.environ.get("WANDB_MODE") != "offline" and not os.environ.get("WANDB_API_KEY"):
        raise ValueError("Set WANDB_API_KEY as an environment secret for W&B tracking")
    # Validate resume records before importing/downloading expensive GPU components.
    from .checkpoints import latest_checkpoint, verify_checkpoint
    if resume:
        checkpoint = latest_checkpoint(path) if str(resume) == 'latest' else Path(resume).resolve()
        if not checkpoint.is_relative_to(path / 'checkpoints'):
            raise ValueError('Resume must reference a checkpoint within this run')
        verify_checkpoint(checkpoint)
    # Import Unsloth before torch/Transformers-dependent modules.
    from unsloth import FastLanguageModel  # noqa: F401
    import torch
    from datasets import Dataset
    from huggingface_hub import model_info
    from transformers import set_seed
    from trl import SFTConfig, SFTTrainer
    info = gpu_info()
    resolved = model_info(config.model_id, revision=config.revision).sha
    config = replace(config, revision=resolved)
    code_hash = implementation_hash()
    env = environment()
    runtime = {'python': env['python'], 'packages': env['packages'], 'bf16': info['bf16']}
    fingerprint = digest({"config": config.to_dict(), "splits": splits, "implementation_sha256": code_hash})
    if resume:
        import json
        old = json.loads((path / "manifest.json").read_text())
        if old["fingerprint"] != fingerprint:
            raise ValueError("Resume requires identical resolved config and dataset")
        if old['smoke_only'] != smoke:
            raise ValueError('Resume must preserve smoke mode')
        if old.get('runtime') != runtime:
            raise ValueError('Resume requires identical Python/package versions and compute precision')
    set_seed(config.seed)
    torch.backends.cudnn.benchmark = False
    manifest = {"status": "running", "smoke_only": smoke, "config": config.to_dict(),
                "fingerprint": fingerprint, "dataset_sha256": digest(splits),
                "implementation_sha256": code_hash,
                "hardware": info, "environment": env, 'runtime': runtime}
    write_json(path / "manifest.json", manifest)
    write_json(path / "config.resolved.json", config.to_dict())
    from .tracking import event, trainer_callback
    event(path, 'resumed' if resume else 'started', fingerprint=fingerprint)
    try:
        model, tokenizer = load_training_model(config)
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token = tokenizer.eos_token
        prepared = {name: Dataset.from_list(encode_rows(splits[name], tokenizer,
                    config.max_length, config.assistant_only_loss)) for name in ("train", "validation")}
        args = SFTConfig(output_dir=str(path/"checkpoints"), max_length=config.max_length,
            max_steps=config.max_steps, learning_rate=config.learning_rate,
            per_device_train_batch_size=config.batch_size, per_device_eval_batch_size=1,
            gradient_accumulation_steps=config.gradient_accumulation_steps,
            gradient_checkpointing=True, bf16=info["bf16"], fp16=not info["bf16"],
            optim="adamw_8bit", packing=False, dataset_kwargs={"skip_prepare_dataset": True},
            remove_unused_columns=False, seed=config.seed, data_seed=config.seed,
            eval_strategy="steps", eval_steps=config.eval_steps, save_strategy="steps",
            save_steps=config.save_steps, save_total_limit=3, logging_steps=1,
            report_to=config.report_to, run_name=path.name, push_to_hub=False)
        trainer = SFTTrainer(model=model, processing_class=tokenizer, args=args,
            train_dataset=prepared["train"], eval_dataset=prepared["validation"],
            data_collator=LabelCollator(tokenizer.pad_token_id),
            callbacks=[trainer_callback(path, checkpoint_sync)])
        result = trainer.train(resume_from_checkpoint=str(checkpoint) if resume else None)
        trainer.save_model(str(path/"adapter"))
        tokenizer.save_pretrained(str(path/"adapter"))
        write_json(path / "training_metrics.json", result.metrics)
        manifest["status"] = "completed"
    except torch.cuda.OutOfMemoryError:
        manifest["status"] = "oom"
        manifest["recovery"] = "Use a new run with shorter max_length/rank. Resume only with identical config from last periodic checkpoint."
        torch.cuda.empty_cache()
        raise RuntimeError("GPU OOM: see persistent manifest and last periodic checkpoint") from None
    except BaseException as exc:
        manifest["status"] = 'interrupted' if isinstance(exc, (KeyboardInterrupt, SystemExit)) else 'failed'
        manifest["error_type"] = type(exc).__name__
        raise
    finally:
        write_json(path / "manifest.json", manifest)
        event(path, manifest['status'])
    return manifest
