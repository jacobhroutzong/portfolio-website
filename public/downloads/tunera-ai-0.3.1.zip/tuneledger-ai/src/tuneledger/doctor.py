"""Read-only runtime capabilities; no model imports or remote allocation."""
import importlib.util
import platform
import shutil
import subprocess
import sys
from pathlib import Path


def doctor():
    info = {'python': platform.python_version(), 'platform': platform.system(),
            'hf_cli': bool(shutil.which('hf') or (Path(sys.executable).parent / ('hf.exe' if platform.system() == 'Windows' else 'hf')).is_file()), 'uv': bool(shutil.which('uv')),
            'colab_mcp': 'Must be discovered by the agent client; cannot infer an attached runtime',
            'gpu_training_supported': platform.system() == 'Linux'}
    for name in ('torch', 'unsloth', 'transformers', 'huggingface_hub'):
        info[name] = importlib.util.find_spec(name) is not None
    if shutil.which('nvidia-smi'):
        result = subprocess.run(['nvidia-smi', '--query-gpu=name,memory.total,memory.free,driver_version',
                                 '--format=csv,noheader'], capture_output=True, text=True, timeout=15)
        info['nvidia_smi'] = result.stdout.strip() if result.returncode == 0 else 'unavailable'
    return info
