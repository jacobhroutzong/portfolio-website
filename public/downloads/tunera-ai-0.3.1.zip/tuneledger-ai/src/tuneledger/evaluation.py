"""Held-out exact-match and JSON-contract metrics; never fabricate measurements."""
import csv
import json
from pathlib import Path
from .artifacts import digest, write_json
from .datasets import normalize, validate


def strict_json(text):
    def reject_constant(value):
        raise ValueError(f'Nonstandard JSON constant: {value}')
    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate JSON key')
            result[key] = value
        return result
    return json.loads(text, parse_constant=reject_constant, object_pairs_hook=unique_object)


def score(prediction, reference, required_keys=None, scorer='exact_match'):
    valid = None
    if required_keys is not None:
        try:
            value = strict_json(prediction)
            valid = isinstance(value, dict) and all(k in value for k in required_keys)
        except (ValueError, TypeError):
            valid = False
    if scorer == 'json_exact':
        expected = strict_json(reference)  # Invalid benchmark references must fail loudly.
        try:
            accuracy = json.dumps(strict_json(prediction), sort_keys=True) == json.dumps(expected, sort_keys=True)
        except (ValueError, TypeError):
            accuracy = False
    elif scorer == 'exact_match':
        accuracy = normalize(prediction) == normalize(reference)
    else:
        raise ValueError('Unknown scorer')
    return {"accuracy": accuracy, "structured_valid": valid}


def evaluate(adapter, rows, output_dir, label, max_new_tokens=128, provenance=None):
    if label not in ('base', 'fine_tuned') or type(max_new_tokens) is not int or max_new_tokens <= 0:
        raise ValueError('Evaluation requires base/fine_tuned label and a positive token budget')
    validate(rows)
    for row in rows:
        if row.get('scorer') == 'json_exact':
            strict_json(row['messages'][-1]['content'])
    results = []
    for row in sorted(rows, key=lambda r: r["id"]):
        generation = adapter.generate(row["messages"][:-1], max_new_tokens)
        reference = row["messages"][-1]["content"]
        results.append({"id": row["id"], "reference": reference, "prediction": generation.text,
            'category': row.get('category', 'uncategorized'), 'scorer': row.get('scorer', 'exact_match'),
            **score(generation.text, reference, row.get("required_keys"), row.get('scorer', 'exact_match')), **generation.to_dict()})
    elapsed = sum(r["latency_seconds"] for r in results)
    structured = [r["structured_valid"] for r in results if r["structured_valid"] is not None]
    peaks = [r["peak_gpu_bytes"] for r in results if r["peak_gpu_bytes"] is not None]
    summary = {"label": label, "count": len(results), "suite_sha256": digest(rows),
        'categories': {category: {'count': len(items), 'accuracy': sum(r['accuracy'] for r in items) / len(items)}
                       for category in sorted({r['category'] for r in results})
                       for items in [[r for r in results if r['category'] == category]]},
        "accuracy": sum(r["accuracy"] for r in results)/len(results),
        "structured_validity": sum(structured)/len(structured) if structured else None,
        "structured_count": len(structured), "mean_latency_seconds": elapsed/len(results),
        "tokens_per_second": sum(r["output_tokens"] for r in results)/elapsed if elapsed > 0 else None,
        "peak_gpu_bytes": max(peaks) if peaks else None,
        "decoding": {"do_sample": False, "max_new_tokens": max_new_tokens, "enable_thinking": False},
        "provenance": provenance or {}, "timing_scope": "generation including prefill, excludes model load; no warmup"}
    path = Path(output_dir)
    write_json(path / f"{label}.json", {"summary": summary, "results": results})
    with (path / f"{label}.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)
    return summary


def compare(base_path, tuned_path, output_dir, max_accuracy_drop=0.0):
    if not 0 <= max_accuracy_drop <= 1:
        raise ValueError("Regression tolerance must be in [0, 1]")
    base, tuned = [json.loads(Path(p).read_text(encoding="utf-8")) for p in (base_path, tuned_path)]
    b, t = base["summary"], tuned["summary"]
    if b["suite_sha256"] != t["suite_sha256"] or b["decoding"] != t["decoding"]:
        raise ValueError("Comparison requires identical held-out suite and decoding")
    for key in ("model_id", "revision", "quantized", "seed"):
        if b["provenance"].get(key) != t["provenance"].get(key):
            raise ValueError(f"Comparison requires identical {key}")
    pairs = list(zip(base["results"], tuned["results"], strict=True))
    if any(r["id"] != s["id"] for r, s in pairs):
        raise ValueError("Comparison result IDs differ")
    lost = [r["id"] for r, s in pairs if r["accuracy"] and not s["accuracy"]]
    delta = t["accuracy"] - b["accuracy"]
    structured_delta = (t["structured_validity"] - b["structured_validity"]
                        if t["structured_validity"] is not None and b["structured_validity"] is not None else None)
    result = {"accuracy_delta": delta, "structured_validity_delta": structured_delta,
              "regression_pass": delta >= -max_accuracy_drop and
                   (structured_delta is None or structured_delta >= -max_accuracy_drop),
              "lost_correct_cases": lost, "base": b, "fine_tuned": t}
    write_json(Path(output_dir)/"comparison.json", result)
    return result
