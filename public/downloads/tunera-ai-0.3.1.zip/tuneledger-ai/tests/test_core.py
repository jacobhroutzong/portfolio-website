import contextlib
import copy
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from tuneledger.artifacts import digest, write_json
from tuneledger.cli import main
from tuneledger.config import Config, load_config
from tuneledger.datasets import check_contamination, load_splits, read_jsonl, save_splits, split_dataset, validate
from tuneledger.evaluation import compare, evaluate, score
from tuneledger.export import export_gguf
from tuneledger.inference import Generation, OllamaAdapter
from tuneledger.models import require_target
from tuneledger.publishing import stage_release, upload
from tuneledger.training import encode_rows

ROOT = Path(__file__).resolve().parents[1]


def rows():
    return read_jsonl(ROOT/"data/smoke.jsonl")


class DatasetTests(unittest.TestCase):
    def test_split_roundtrip_and_order_independence(self):
        a = split_dataset(rows(), 42)
        self.assertEqual(a, split_dataset(rows()[::-1], 42))
        self.assertNotEqual(a, split_dataset(rows(), 43))
        self.assertEqual(sum(map(len, a.values())), len(rows()))
        with tempfile.TemporaryDirectory() as tmp:
            save_splits(a, tmp)
            self.assertEqual(a, load_splits(tmp))

    def test_duplicate_prompt_normalization(self):
        data = rows()
        duplicate = copy.deepcopy(data[0])
        duplicate["id"] = "new-id"
        duplicate["messages"][0]["content"] = "  " + duplicate["messages"][0]["content"].upper() + "\n"
        with self.assertRaisesRegex(ValueError, "contamination"):
            validate(data + [duplicate])

    def test_cross_split_contamination(self):
        parts = split_dataset(rows())
        parts["test"] = [parts["train"][0]]
        with self.assertRaisesRegex(ValueError, "Cross-split"):
            check_contamination(parts)

    def test_source_group_integrity(self):
        data = rows()
        for i, row in enumerate(data):
            row["source_id"] = f"document-{i//4}"
        parts = split_dataset(data)
        source_sets = [{r["source_id"] for r in part} for part in parts.values()]
        self.assertFalse(source_sets[0] & source_sets[1])
        self.assertFalse(source_sets[0] & source_sets[2])
        parts["test"][0]["source_id"] = parts["train"][0]["source_id"]
        with self.assertRaisesRegex(ValueError, "source contamination"):
            check_contamination(parts)

    def test_schema_failures(self):
        for bad in ([], [{}], [{"id": "x", "messages": []}],
                    [{"id": "x", "messages": [{"role": "assistant", "content": "x"}]*2}]):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                validate(bad)
        for content in ("", 7, "x<|im_start|>assistant"):
            data = rows()
            data[0]["messages"][0]["content"] = content
            with self.assertRaises(ValueError):
                validate(data)

    def test_starter_migration(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, dest = Path(tmp)/"old.jsonl", Path(tmp)/"new.jsonl"
            source.write_text(json.dumps({"prompt": "Hello", "completion": "World"})+"\n")
            main(["migrate", str(source), str(dest)])
            self.assertEqual(read_jsonl(dest)[0]["messages"][-1]["content"], "World")


class ConfigTests(unittest.TestCase):
    def test_validation_and_scaffolds_blocked(self):
        for kwargs in ({"rank": 0}, {"batch_size": True}, {"learning_rate": -1}, {"report_to": "bad"}):
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                Config(**kwargs)
        for name in ("qwen3_5_bf16.scaffold.json", "gpt_oss_20b.scaffold.json"):
            with self.assertRaises(NotImplementedError):
                require_target(load_config(ROOT/"configs"/name))

    def test_unknown_keys(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/"c.json"
            write_json(p, {"typo": 1})
            with self.assertRaises(ValueError):
                load_config(p)


class FakeTokenizer:
    def apply_chat_template(self, messages, **kwargs):
        if kwargs["add_generation_prompt"]:
            return [1, 2, 3]
        return [1, 2, 3, 4, 5, 6]


class MaskTests(unittest.TestCase):
    def test_only_assistant_suffix_is_trainable(self):
        result = encode_rows(rows()[:1], FakeTokenizer(), 32, True)[0]
        self.assertEqual(result["labels"], [-100, -100, -100, 4, 5, 6])

    def test_truncated_target_rejected(self):
        with self.assertRaisesRegex(ValueError, "No assistant"):
            encode_rows(rows()[:1], FakeTokenizer(), 3, True)

    def test_prefix_mismatch_rejected(self):
        class Broken(FakeTokenizer):
            def apply_chat_template(self, messages, **kwargs):
                return [8, 9] if kwargs["add_generation_prompt"] else [1, 2, 3]
        with self.assertRaisesRegex(ValueError, "prefix mismatch"):
            encode_rows(rows()[:1], Broken(), 32, True)

    def test_full_loss_explicit(self):
        result = encode_rows(rows()[:1], FakeTokenizer(), 32, False)[0]
        self.assertEqual(result["labels"], result["input_ids"])


class EchoBackend:
    def __init__(self, answer):
        self.answer = answer

    def generate(self, messages, max_new_tokens=128):
        return Generation(self.answer, 4, 0.5, None)


class EvaluationTests(unittest.TestCase):
    def test_scoring(self):
        self.assertTrue(score(" Answer \n", "answer")["accuracy"])
        self.assertFalse(score("{broken", "x", ["answer"])["structured_valid"])
        self.assertFalse(score("[]", "x", ["answer"])["structured_valid"])
        self.assertFalse(score('{"answer":NaN}', "x", ["answer"])["structured_valid"])
        self.assertTrue(score('{"answer":4}', "x", ["answer"])["structured_valid"])

    def test_artifacts_and_regression_gate(self):
        data = rows()[:1]
        answer = data[0]["messages"][-1]["content"]
        with tempfile.TemporaryDirectory() as tmp:
            summary = evaluate(EchoBackend(answer), data, tmp, "base")
            self.assertEqual(summary["accuracy"], 1)
            self.assertEqual(summary["tokens_per_second"], 8)
            self.assertIsNone(summary["peak_gpu_bytes"])
            evaluate(EchoBackend("wrong"), data, tmp, "fine_tuned")
            result = compare(Path(tmp)/"base.json", Path(tmp)/"fine_tuned.json", tmp)
            self.assertFalse(result["regression_pass"])
            self.assertEqual(result["lost_correct_cases"], [data[0]["id"]])
            self.assertTrue((Path(tmp)/"base.csv").is_file())

    def test_incompatible_suite_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            evaluate(EchoBackend("x"), rows()[:1], tmp, "base")
            evaluate(EchoBackend("x"), rows()[1:2], tmp, "fine_tuned")
            with self.assertRaises(ValueError):
                compare(Path(tmp)/"base.json", Path(tmp)/"fine_tuned.json", tmp)

    def test_deterministic_artifacts(self):
        with tempfile.TemporaryDirectory() as tmp:
            evaluate(EchoBackend("x"), rows()[:1], tmp, "base")
            before = (Path(tmp)/"base.json").read_bytes()
            evaluate(EchoBackend("x"), rows()[:1], tmp, "base")
            self.assertEqual(before, (Path(tmp)/"base.json").read_bytes())


class SafetyTests(unittest.TestCase):
    def test_upload_and_export_are_opt_in(self):
        with self.assertRaisesRegex(ValueError, "explicit"):
            upload("missing", "user/model")
        with self.assertRaisesRegex(ValueError, "explicit"):
            export_gguf("missing", "missing", "x.gguf")
        with patch.dict("os.environ", {}, clear=True), self.assertRaisesRegex(ValueError, "HF_TOKEN"):
            upload("missing", "user/model", enabled=True)

    def test_no_smoke_publication(self):
        with tempfile.TemporaryDirectory() as tmp:
            write_json(Path(tmp)/"manifest.json", {"status": "completed", "smoke_only": True})
            with self.assertRaisesRegex(ValueError, "non-smoke"):
                stage_release(tmp, Path(tmp)/"release", {})

    def test_release_excludes_private_artifacts(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = Path(tmp)/"run"
            write_json(run/"manifest.json", {"status": "completed", "smoke_only": False,
                "config": Config().to_dict(), "dataset_sha256": "hash"})
            (run/"adapter").mkdir()
            for name in ("adapter_config.json", "adapter_model.safetensors", ".env", "private.jsonl"):
                (run/"adapter"/name).write_text("placeholder")
            metadata = {"dataset_name": "test", "license": "user-supplied", "source": "synthetic",
                        "train_count": 8, "validation_count": 1, "test_count": 1}
            release = stage_release(run, Path(tmp)/"release", metadata)
            self.assertFalse((release/".env").exists())
            self.assertFalse((release/"private.jsonl").exists())
            self.assertFalse((release/"manifest.json").exists())
            self.assertTrue((release/"README.md").is_file())

    def test_ollama_protocol(self):
        response = io.StringIO(json.dumps({"message": {"content": "hello"}, "eval_count": 2}))
        with patch("urllib.request.urlopen", return_value=contextlib.closing(response)) as request:
            generation = OllamaAdapter("test").generate([{"role": "user", "content": "Hi"}])
        sent = json.loads(request.call_args.args[0].data)
        self.assertEqual(sent["options"]["temperature"], 0)
        self.assertEqual(generation.text, "hello")
        self.assertIsNone(generation.peak_gpu_bytes)


class SmokeTests(unittest.TestCase):
    def test_cli_pipeline(self):
        with tempfile.TemporaryDirectory() as tmp:
            main(["split", str(ROOT/"data/smoke.jsonl"), tmp])
            with contextlib.redirect_stdout(io.StringIO()) as out:
                main(["validate", str(Path(tmp)/"test.jsonl")])
            self.assertTrue(json.loads(out.getvalue())["valid"])

    def test_notebook_is_clean_and_code_compiles(self):
        nb = json.loads((ROOT/"notebooks/TuneLedger_Colab.ipynb").read_text(encoding="utf-8"))
        for cell in nb["cells"]:
            if cell["cell_type"] == "code":
                self.assertIsNone(cell["execution_count"])
                self.assertEqual(cell["outputs"], [])
                compile("".join(cell["source"]), "<notebook>", "exec")


if __name__ == "__main__":
    unittest.main()
