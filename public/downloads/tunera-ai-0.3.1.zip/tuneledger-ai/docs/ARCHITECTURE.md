# Architecture and execution boundaries

The package is independent of the compute provider. `train` owns model loading,
tokenization, masked labels, the Trainer, metrics and checkpoint lifecycle.
`pipeline` invokes training and paired evaluation in separate processes so a
base model and its adapted copy do not compete for GPU memory.

| Layer | Implementation |
|---|---|
| Data | Strict conversations, IDs, normalized prompt hashes, source-group isolation, seeded splits |
| Configuration | Immutable dataclass, unknown-key rejection, numeric and target validation |
| Models | Registry for Qwen3 0.6B, 1.7B, 4B and 8B, shared Unsloth QLoRA implementation |
| Training | Official pinned tokenizer, final-assistant supervision, TRL, 8-bit optimizer, accumulation, FP16/BF16 |
| Tracking | Atomic manifest, resolved config, JSONL events, metrics, runtime/source/data fingerprints |
| Recovery | Hashed completion marker after Trainer save; full optimizer/scheduler/RNG/weights required |
| Evaluation | Greedy Transformers or Ollama adapter, exact or JSON equality, category metrics, latency/tokens/memory |
| Runners | Local and attached Colab subprocess adapters; immutable, bounded HF Jobs specification |
| Persistence | Drive/local durable directory; optional private Hub snapshots at each checkpoint |
| Release | Curated model allowlist; independent CPU Gradio Space staging; portfolio embed |

Registered Qwen3 variants share an architecture implementation; registration is
not hardware validation. Only Qwen3-4B's real tokenizer has been tested here.
Qwen3.5 and gpt-oss remain explicit, blocked scaffolds. Adding a new architecture
requires a loader, tokenizer/masking contract, immutable model revision,
resource preflight and GPU acceptance run. DPO, GRPO, multimodal and distributed
training are not implemented.

## Experiment lifecycle

Plan offline → validate all splits → inspect CUDA → resolve model commit →
record config/data/source/runtime → train → checkpoint and seal → evaluate base
and adapter → compare → stage an explicitly reviewed release.

The test split is validated for contamination but is never supplied to the
Trainer. Use validation for model selection. Evaluation outputs contain private
references and predictions; Space staging exports only selected aggregate fields.
The synthetic acceptance suite covers extraction, formatting, reasoning and
multiturn behavior. It is a regression fixture, not an established benchmark or
evidence of model improvement. Supply licensed domain benchmarks before portfolio
quality claims. JSON equality preserves value types and ignores object key order;
plain exact match normalizes Unicode, case and whitespace.

## Failure and recovery

`manifest.json` records running/completed/oom/failed/interrupted. Abrupt process
or VM termination can leave it running; use the latest verified checkpoint.
`complete.json` is written after the Trainer's save callback, with SHA-256 for
all checkpoint files. Partial, modified and extra files are rejected. `--resume
latest` skips incomplete checkpoints. Recovery requires unchanged config, split
contents, package source, Python/package versions and compute precision. GPU
kernels can still prevent bitwise determinism. Only single-GPU training is
implemented. Never unpickle optimizer state from an untrusted repository.

Checkpoint upload failures stop training and retain the verified local state.
HF workers sync on save and in a finalizer. A hard timeout can prevent the
finalizer, and Hub outages can prevent durability; a successful checkpoint commit
is the recovery boundary. A single private model repository stores one experiment.
Local checkpoint retention is three; older remote files are retained, so monitor
Hub storage. Dataset repositories are separate, pinned and private as appropriate.

HF Job plans require an immutable container image, dataset commit and model
commit, and a timeout of 60–86,400 seconds. Timeout limits runtime, not a currency
budget. Pricing must be reviewed for the actual flavor before approval. HF
credentials are passed through the SDK secret channel; they are never in a
plan, command line or manifest. W&B is opt-in; local event tracking is always on.

## External API references

The SDK's installed `HfApi.run_job` signature is checked by a CPU contract test.
The implementation follows [HF Jobs](https://huggingface.co/docs/huggingface_hub/guides/jobs).
The official [Colab MCP server](https://github.com/googlecolab/colab-mcp)
requires a local client supporting dynamic tool-list notifications and an
attached browser session. No Colab MCP tools are available in this session.
