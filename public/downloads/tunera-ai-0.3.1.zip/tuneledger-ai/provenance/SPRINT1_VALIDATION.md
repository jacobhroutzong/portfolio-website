# Sprint 1 implementation and execution record

Date: 2026-10-18. Host: Windows, Python 3.12.14, uv 0.13.0.
All added source files are under `adaptforge-ai/`; the preexisting portfolio
website was preserved. `AdaptForge_AI_Sprint1.zip` is the standalone handoff.

## Files added

| Files | Purpose |
|---|---|
| `pyproject.toml`, `uv.lock`, `.gitignore`, `.env.example`, `LICENSE` | Installable package, dependency lock, local-data/credential exclusions |
| `src/adaptforge/__init__.py`, `config.py`, `artifacts.py`, `cli.py` | Package version, strict configuration, atomic JSON/manifests, CLI |
| `src/adaptforge/models.py`, `datasets.py`, `training.py` | Target gating, validation/splits, Unsloth QLoRA + TRL training/resume |
| `src/adaptforge/inference.py`, `evaluation.py` | Transformers/Ollama adapters, deterministic suite ordering, JSON/CSV, regression gates |
| `src/adaptforge/publishing.py`, `export.py` | Explicit HF publication and optional compatibility-checked GGUF conversion |
| `configs/qwen3_4b.json`, `qwen3_5_bf16.scaffold.json`, `gpt_oss_20b.scaffold.json` | Pinned first target and blocked future-target scaffolds |
| `tests/test_core.py`, `tests/test_official_tokenizer.py` | CPU suite and explicit real-tokenizer integration checks |
| `data/smoke.jsonl` | Forty synthetic JSON arithmetic examples; no benchmark claims |
| `notebooks/AdaptForge_Colab.ipynb` | Clean Colab orchestration, Drive persistence, smoke gate, opt-in long run |
| `space/app.py`, `space/README.md`, `space/requirements.txt`, `space/requirements.lock` | Independent CPU UI, optional inference gateway, locked dependencies |
| `.github/workflows/ci.yml` | CPU install/test/build matrix; active when this directory is the repository root |
| `provenance/starter_archive.json`, `provenance/starter_example.jsonl` | Supplied zip checksum/member list and original schema example |
| `scripts/package_repo.py` | Reproducible handoff archive excluding runtime artifacts/private data |
| `README.md`, `docs/CUDA_COMPATIBILITY.md`, `docs/VALIDATION.md` | Reproduction, costs, limitations, exact Colab steps, validation evidence |

## Commands executed and outcomes

Commands below were executed from the parent workspace unless stated otherwise.
`PY` refers to `adaptforge-ai/.venv/Scripts/python.exe` for CPU testing; the
bundled interpreter used to create the venv was Python 3.12.14. `UV_CACHE_DIR`
was redirected to the workspace. Windows `TEMP` and `TMP` were redirected to
`adaptforge-ai/artifacts/test-tmp` for unit tests because the initial sandbox
temporary-directory attempt stalled; that attempt was interrupted.

```text
uv lock --project adaptforge-ai
uv lock --project adaptforge-ai --check --offline
uv export --project adaptforge-ai --frozen --extra space --no-emit-project --format requirements-txt --output-file adaptforge-ai/space/requirements.lock
uv sync --project adaptforge-ai --frozen --python <bundled-python-3.12>
PY -m unittest discover -s adaptforge-ai/tests -v
PY -m compileall -q adaptforge-ai/src adaptforge-ai/space adaptforge-ai/scripts
adaptforge-ai/.venv/Scripts/adaptforge.exe validate adaptforge-ai/data/smoke.jsonl
adaptforge-ai/.venv/Scripts/adaptforge.exe split adaptforge-ai/data/smoke.jsonl adaptforge-ai/artifacts/smoke-splits
uv build --project adaptforge-ai
uv build --project adaptforge-ai --offline
uv venv adaptforge-ai/artifacts/wheel-check --python <bundled-python-3.12>
uv pip install --python adaptforge-ai/artifacts/wheel-check/Scripts/python.exe --no-deps adaptforge-ai/dist/adaptforge_ai-0.1.0-py3-none-any.whl
uv pip install --python adaptforge-ai/artifacts/wheel-check/Scripts/python.exe --reinstall --no-deps adaptforge-ai/dist/adaptforge_ai-0.1.0-py3-none-any.whl
adaptforge-ai/artifacts/wheel-check/Scripts/adaptforge.exe validate adaptforge-ai/data/smoke.jsonl
```

- Dependency lock: **130 resolved packages**; complete optional graph locked.
  Initial trial pins conflicted with current Unsloth/PEFT; corrected based on
  resolver evidence. Linux-only Unsloth marker resolves its Triton Windows
  constraint. Final lock consistency check passed.
- Package: editable installation, source build, wheel build, fresh wheel install,
  and reinstallation of final wheel **passed**. Built distributions were inspected
  to confirm private/runtime/cache directories were excluded.
- CPU suite: **24 discovered, 22 passed, 2 integration checks skipped** by default.
  No CPU test failed. These cover data/schema/source contamination, migration,
  deterministic splits, loss masking and rejection cases, exact/structured metrics,
  regression gating, JSON/CSV artifacts, mocked Ollama transport, publication
  exclusions, export/upload opt-in behavior and notebook syntax/clean outputs.
- CLI validation: **40 valid synthetic rows**. Train/validation/test split smoke
  succeeded; metadata hashes and all three JSONL files were produced locally.
- Python compilation passed. The notebook code cells compile without IPython-only
  magics; all execution counts are null and outputs empty.

The real tokenizer checks were **also executed separately**, rather than counted
as validated merely because they were skipped in the dependency-free suite:

```text
uv venv adaptforge-ai/artifacts/tokenizer-env --python <bundled-python-3.12>
uv pip install --python adaptforge-ai/artifacts/tokenizer-env/Scripts/python.exe transformers==4.57.6
uv pip install --python adaptforge-ai/artifacts/tokenizer-env/Scripts/python.exe jinja2==3.1.6
# Set PYTHONPATH=adaptforge-ai/src, HF_HOME=adaptforge-ai/artifacts/hf-cache,
# ADAPTFORGE_TOKENIZER_TEST=1; after download also set HF_HUB_OFFLINE=1.
adaptforge-ai/artifacts/tokenizer-env/Scripts/python.exe -m unittest discover -s adaptforge-ai/tests -p test_official_tokenizer.py -v
```

Result: **2/2 passed** using official `Qwen/Qwen3-4B` tokenizer revision
`1cfa9a7208912126459214e8b04321603b3df60c`, Transformers 4.57.6. The test confirms
masked labels decode to the exact final assistant answer for the contract case,
all 40 smoke examples at the smoke length limit, and a system/multiturn case.
The tokenizer-only environment initially lacked Jinja2; installing its renderer
resolved that test setup failure. This environment downloaded **no model weights**
and loaded no GPU model. Training dependencies include Jinja2 transitively.

Initial sandbox DNS and uv cache rename restrictions were resolved during
dependency setup. No credentials or private datasets were read, published,
or included in artifacts.

## Unresolved execution and limitations

- **GPU acceptance remains pending**: no Colab training, loss/VRAM result,
  optimizer checkpoint recovery, real model generation or base/tuned benchmark
  has run. Run the supplied two-step Colab smoke before a long job.
- Dependency resolution is not CUDA kernel compatibility certification.
  Colab driver, GPU allocation, runtime disk and memory must pass the actual
  preflight/import/training gate. Use the documented candidate CUDA matrix.
- Local RTX 4070 inference, live Ollama, HF publication, Gradio runtime/deployment,
  W&B remote tracking and merged/GGUF export have not been integration-tested.
- Qwen3.5/gpt-oss scaffolds deliberately raise `NotImplementedError` at training.
- Semantic paraphrase detection requires an additional dataset curation step.
  Source separation only works with reliable `source_id` annotations.
- Scores and performance fields in unit tests use explicit test doubles; they
  are assertions about report logic, not measured model benchmark results.
- Remote GitHub Actions has not executed. Copy this directory to a standalone
  GitHub repository to activate its root `.github/workflows/ci.yml`.

Next Colab steps are numbered in the README. No deployment, paid-resource
provisioning, HF upload, DPO, GRPO, multimodal work or scaling was attempted.
