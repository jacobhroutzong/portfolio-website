"""Container/Colab worker. Hub writes are explicitly authorized by the launcher."""
import json
import os
from pathlib import Path
from .artifacts import write_json
from .datasets import load_splits
from .hub import restore_run, sync_run
from .runners import JobSpec


def main():
    from huggingface_hub import snapshot_download
    spec = JobSpec(**json.loads(os.environ['TUNELEDGER_JOB']))
    root = Path(os.environ.get('TUNELEDGER_WORKDIR', '/workspace'))
    data = root / 'data'
    snapshot_download(spec.dataset_repo, repo_type='dataset', revision=spec.dataset_revision,
                      local_dir=str(data), allow_patterns=['train.jsonl', 'validation.jsonl', 'test.jsonl'])
    load_splits(data)
    run = root / 'runs' / spec.run_name
    resume = None
    if spec.resume_revision:
        resume = restore_run(spec.artifact_repo, spec.resume_revision, run, spec.owner, enabled=True)
    def sync(path):
        return sync_run(path, spec.artifact_repo, spec.owner, enabled=True)
    # Initial write fails before expensive model loading if storage/auth is unusable.
    run.mkdir(parents=True, exist_ok=True)
    write_json(run / 'job.json', {'run_name': spec.run_name, 'dataset_revision': spec.dataset_revision})
    sync(run)
    try:
        from .pipeline import pipeline
        config_path = root / 'experiment.json'
        write_json(config_path, spec.config)
        result = pipeline(config_path, data, run, resume=resume, smoke=spec.smoke,
                          execute=True, checkpoint_repo=spec.artifact_repo)
        if result['status'] == 'regression':
            raise RuntimeError('Held-out evaluation regression gate failed')
    finally:
        sync(run)


if __name__ == '__main__':
    main()
