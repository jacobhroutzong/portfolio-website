"""Optional real-tokenizer contract test, run in Colab before model loading."""
import os
import unittest
from tuneledger.training import encode_rows
from tuneledger.config import Config


@unittest.skipUnless(os.environ.get("TUNELEDGER_TOKENIZER_TEST") == "1", "requires official tokenizer download")
class OfficialTokenizerTests(unittest.TestCase):
    def test_real_template_mask(self):
        from transformers import AutoTokenizer
        tok = AutoTokenizer.from_pretrained("Qwen/Qwen3-4B", revision=os.environ.get("TUNELEDGER_REVISION", Config().revision))
        messages = [{"role": "user", "content": "Return a JSON object."},
                    {"role": "assistant", "content": '{"answer": 42}'}]
        row = encode_rows([{"id": "mask-check", "messages": messages}], tok, 512, True)[0]
        labels = [i for i in row["labels"] if i != -100]
        self.assertEqual(tok.decode(labels, skip_special_tokens=True).strip(), '{"answer": 42}')

    def test_smoke_fixture_and_multiturn(self):
        from pathlib import Path
        from transformers import AutoTokenizer
        from tuneledger.datasets import read_jsonl
        tok = AutoTokenizer.from_pretrained("Qwen/Qwen3-4B", revision=Config().revision)
        rows = read_jsonl(Path(__file__).resolve().parents[1]/"data/smoke.jsonl")
        encoded = encode_rows(rows, tok, 256, True)
        for row, result in zip(rows, encoded):
            labels = [i for i in result["labels"] if i != -100]
            self.assertEqual(tok.decode(labels, skip_special_tokens=True).strip(), row["messages"][-1]["content"])
        messages = [{"role": "system", "content": "Be concise."},
                    {"role": "user", "content": "First"}, {"role": "assistant", "content": "Earlier response"},
                    {"role": "user", "content": "Second"}, {"role": "assistant", "content": "Final response"}]
        result = encode_rows([{"id": "multi", "messages": messages}], tok, 512, True)[0]
        labels = [i for i in result["labels"] if i != -100]
        self.assertEqual(tok.decode(labels, skip_special_tokens=True).strip(), "Final response")
