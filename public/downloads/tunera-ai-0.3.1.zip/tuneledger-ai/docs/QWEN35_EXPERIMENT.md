# Qwen3.5-2B BF16 LoRA experiment

This text-only recipe uses `Qwen/Qwen3.5-2B` at
`15852e8c16360a2fea060d615a32b45270f8a8fc`. It adapts language projections with
PEFT and loads the model in BF16. The vision tower remains frozen. The official
chat template renders the dialogue. Tunera masks everything before the final
assistant answer and fails if the template prefix differs at the token level.
See the [Qwen model card](https://huggingface.co/Qwen/Qwen3.5-2B) and the
[Unsloth text LoRA guide](https://unsloth.ai/docs/models/qwen3.5/fine-tune).

The existing Qwen3 runtime pins Transformers 4.x. The experimental runtime pins
Transformers 5.13.0 and PEFT 0.20.0 in a separate Python 3.12 Linux x86-64 CUDA
12.8 environment. This avoids changing the Qwen3 package source, fingerprint,
configurations, CLI, and lock. The experiment uses Transformers Trainer directly
and shares Tunera's encoding, collation, checkpoints, events and evaluator.
Use a GPU with native BF16 CUDA, such as an L4 or an RTX 4070. A T4 lacks native
BF16. Free memory at start and memory after weight load both matter.

## Prepare and plan

From the repository root, split the provided public smoke data with the
standard Tunera CLI. The recipe prints a plan unless you pass `--execute`.

```bash
tuneledger split data/smoke.jsonl artifacts/qwen35-data
PYTHONPATH=src python -m tuneledger.experimental.qwen35 \
  --config configs/qwen3_5_2b.experimental.json --data artifacts/qwen35-data \
  --output artifacts/qwen35-run --smoke
```

## Run in the isolated environment

```bash
uv venv --python 3.12 artifacts/qwen35-env
uv pip sync --python artifacts/qwen35-env/bin/python --require-hashes deployment/qwen35-requirements.lock
PYTHONPATH=src artifacts/qwen35-env/bin/python -m tuneledger.experimental.qwen35 \
  --config configs/qwen3_5_2b.experimental.json --data artifacts/qwen35-data \
  --output artifacts/qwen35-run --smoke --execute
```

The smoke run performs two optimizer updates, validates and saves after each
update, and records peak allocated and reserved GPU bytes. It writes a manifest,
events, training metrics, adapter and sealed Trainer checkpoints. Use the same
command with `--resume latest` or `--resume checkpoint-1` to restore an intact
checkpoint with identical settings, split data, recipe source and runtime.

## Measure the base and adapter

```bash
for label in base fine_tuned; do
  PYTHONPATH=src artifacts/qwen35-env/bin/python -m tuneledger.experimental.qwen35_eval \
    --run artifacts/qwen35-run --data artifacts/qwen35-data --label "$label"
done
tuneledger compare artifacts/qwen35-run/evaluation/base.json artifacts/qwen35-run/evaluation/fine_tuned.json \
  artifacts/qwen35-run/evaluation
```

The evaluation reads the verified test split and records the run fingerprint and
smoke status. The Colab Pro NVIDIA L4 acceptance run used the same checked-in
recipe without `--smoke` and completed 20 optimizer steps. A fresh process resumed
from sealed `checkpoint-15` and finished at step 20. The recovered run peaked at
4.33 GiB allocated. On four held-out synthetic cases the base model passed 0/4
and the recovered adapter passed 4/4. Both produced valid structured output on
all four cases, and the paired regression gate passed.

To repeat the acceptance workflow, use a new run directory, omit `--smoke`,
and rerun with `--resume checkpoint-15` in a fresh process. Keep an untouched
copy of the initial run if comparing recovery artifacts. Then evaluate the
recovered adapter with the commands above. The default seed of 42 splits the
public smoke dataset into 32 train, 4 validation and 4 test rows. The acceptance
test split SHA-256 is
`48360ebd7c19def5aeda5a5c4a831a097bfab0d4ee37c156054c820e01c2008b`.
See the
[published run summary](https://jacobroutzong.dev/projects/tunera/#qwen35-gpu-validation).

This is a GPU-tested experimental recipe. The four synthetic cases establish
execution and recovery for the reference settings. Promotion requires
independent representative data and reviewed evaluation evidence. Qwen3-4B
QLoRA remains the default.
