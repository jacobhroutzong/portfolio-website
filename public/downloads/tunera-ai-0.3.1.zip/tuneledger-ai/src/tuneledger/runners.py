"""Provider adapters produce reviewable plans before executing any compute."""
import json
import re
import subprocess
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from .artifacts import digest, implementation_hash
from .config import load_config
from .datasets import load_splits
from .models import require_target


@dataclass(frozen=True)
class JobSpec:
    image: str
    dataset_repo: str
    dataset_revision: str
    artifact_repo: str
    config: dict
    run_name: str
    owner: str = 'jacobroutzong'
    flavor: str = 'a10g-small'
    timeout_seconds: int = 1800
    smoke: bool = True
    resume_revision: str | None = None

    def __post_init__(self):
        if not re.fullmatch(r'[\w.-]+', self.run_name) or self.run_name in ('.', '..'):
            raise ValueError('Invalid run name')
        if not re.fullmatch(r'[\w./:-]+@sha256:[0-9a-f]{64}', self.image):
            raise ValueError('Use an immutable container image digest')
        for repo in (self.dataset_repo, self.artifact_repo):
            if not re.fullmatch(r'[\w.-]+/[\w.-]+', repo):
                raise ValueError('Invalid Hub repository ID')
        if self.artifact_repo.split('/')[0] != self.owner:
            raise ValueError('Artifact repository must belong to intended owner')
        for sha in (self.dataset_revision, self.resume_revision):
            if sha is not None and not re.fullmatch('[0-9a-f]{40}', sha):
                raise ValueError('Hub inputs require immutable revisions')
        if type(self.timeout_seconds) is not int or not 60 <= self.timeout_seconds <= 86400:
            raise ValueError('Timeout must be bounded between 60 and 86400 seconds')
        if type(self.smoke) is not bool or not re.fullmatch(r'[a-z0-9-]+', self.flavor):
            raise ValueError('Invalid smoke flag or hardware flavor')
        from .config import Config
        config = Config(**self.config)
        require_target(config)
        if not re.fullmatch('[0-9a-f]{40}', config.revision):
            raise ValueError('Remote jobs require pinned model revision')


def local_plan(config_path, data, output, smoke=False, resume=None):
    config = load_config(config_path)
    require_target(config)
    splits = load_splits(data)
    command = [sys.executable, '-m', 'tuneledger.cli', 'train', '--config', str(config_path),
               '--data', str(data), '--output', str(output)]
    if smoke:
        command.append('--smoke')
    if resume:
        command.extend(['--resume', str(resume)])
    return {'provider': 'local', 'command': command, 'config': config.to_dict(),
            'counts': {k: len(v) for k, v in splits.items()}, 'dataset_sha256': digest(splits),
            'implementation_sha256': implementation_hash(), 'network': False,
            'note': 'Planning is offline; execution downloads weights and requires CUDA.'}


class LocalRunner:
    def submit(self, plan, execute=False):
        if not execute:
            return plan
        return subprocess.run(plan['command'], check=True).returncode


class ColabRunner(LocalRunner):
    """Execute inside an attached Colab runtime through the same CLI."""
    def submit(self, plan, execute=False):
        if execute:
            import importlib.util
            try:
                attached = importlib.util.find_spec('google.colab') is not None
            except ModuleNotFoundError:
                attached = False
            if not attached:
                raise RuntimeError('Execute this plan inside Colab; no Colab MCP runtime is attached here')
        return super().submit(plan, execute)


class HFJobsRunner:
    def manage(self, job_id, action='status', owner='jacobroutzong', execute=False):
        if not re.fullmatch(r'[\w-]+', job_id):
            raise ValueError('Invalid job ID')
        if action not in ('status', 'logs', 'cancel'):
            raise ValueError('Unknown job action')
        if action == 'cancel' and not execute:
            raise ValueError('Cancel requires explicit --execute')
        from .hub import authenticated_api
        api = authenticated_api(f'{owner}/tuneledger-auth-check', owner)
        if action == 'logs':
            return list(api.fetch_job_logs(job_id=job_id, namespace=owner))
        if action == 'cancel':
            api.cancel_job(job_id=job_id, namespace=owner)
            return {'id': job_id, 'cancel_requested': True}
        job = api.inspect_job(job_id=job_id, namespace=owner)
        return {'id': job.id, 'url': job.url, 'stage': job.status.stage, 'message': job.status.message}

    def plan(self, spec):
        return {'provider': 'hf-jobs', 'spec': asdict(spec),
                'command': ['python', '-m', 'tuneledger.worker'],
                'environment': {'TUNELEDGER_JOB': json.dumps(asdict(spec), sort_keys=True)},
                'secret_names': ['HF_TOKEN'], 'billable': True}

    def submit(self, spec, execute=False, approve_cost=False):
        plan = self.plan(spec)
        if not execute:
            return plan
        if not approve_cost:
            raise ValueError('Billable Jobs require explicit cost approval')
        from .hub import authenticated_api
        api = authenticated_api(spec.artifact_repo, spec.owner)
        if api.repo_exists(spec.artifact_repo):
            if not api.repo_info(spec.artifact_repo).private:
                raise ValueError('Experiment storage must be private')
            if not spec.resume_revision and api.file_exists(spec.artifact_repo, 'manifest.json'):
                raise ValueError('Use a fresh artifact repository or explicit resume revision')
        dataset = api.dataset_info(spec.dataset_repo, revision=spec.dataset_revision)
        files = {p.rfilename for p in dataset.siblings}
        if not {'train.jsonl', 'validation.jsonl', 'test.jsonl'} <= files:
            raise ValueError('Dataset repository requires all three split files at its root')
        # token values never enter plans, command lines, logs or local artifacts.
        from huggingface_hub import get_token
        job = api.run_job(image=spec.image, command=plan['command'], flavor=spec.flavor,
                          timeout=spec.timeout_seconds, env=plan['environment'],
                          secrets={'HF_TOKEN': get_token()}, namespace=spec.owner)
        return {'id': job.id, 'url': job.url, 'owner': spec.owner}


def load_job(path):
    return JobSpec(**json.loads(Path(path).read_text(encoding='utf-8')))
