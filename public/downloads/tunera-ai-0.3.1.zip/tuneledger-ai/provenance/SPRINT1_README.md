# AdaptForge AI — Sprint 1

Colab-first LLM specialization with an installable `src/adaptforge` package.
Qwen3-4B Unsloth QLoRA is **implemented; real GPU validation is pending**.
Qwen3.5 BF16 LoRA and gpt-oss-20b are blocked scaffolds, not supported targets.
No trained model, benchmark result, or claim of improvement is included.

This repository adapts `AdaptForge_AI_Colab_Starter.zip`. Its original
prompt/completion schema is supported by `adaptforge migrate`; the new notebook
delegates training and evaluation to the package. Archive checksum and migration
notes are in `provenance/`. The original portfolio website beside this directory
is unchanged. For a standalone GitHub repository, use **this directory's contents
as the repository root**, including its `.github/` directory.

## Install and CPU verification

Python 3.11–3.13 on Linux or Windows; Colab training uses Linux/Python 3.12.
Install uv 0.13.0, then from this directory:

```bash
uv sync --frozen
uv run --frozen python -m unittest discover -s tests -v
uv run --frozen adaptforge validate data/smoke.jsonl
uv run --frozen adaptforge split data/smoke.jsonl artifacts/smoke-splits
uv build
```

Core operations have no third-party runtime dependencies. GPU imports are lazy.
`uv.lock` locks the complete optional training/inference/Space dependency graph
with artifact hashes. Use `--frozen`; changing dependencies requires a deliberate
`uv lock`, review, and a fresh GPU smoke run. Plain `pip install .` installs the
CPU core; `pip install .[gpu]` does **not** enforce the transitive uv lock.
The standalone Space has a derived hash-pinned `requirements.lock`.

## Colab execution — exact next steps

1. Open `notebooks/AdaptForge_Colab.ipynb` in Google Colab. Select
   **Runtime → Change runtime type → GPU**. L4/A100 are preferable; the smoke
   gate determines whether the allocated hardware and software actually work.
2. Leave `REPO_URL` empty to upload the delivered `adaptforge-ai.zip` when
   prompted. Alternatively set your GitHub URL and full 40-character commit SHA.
   Set a fresh `RUN_NAME`; leave `RUN_LONG=False` and `RESUME_CHECKPOINT=None`.
3. Optionally add `HF_TOKEN` and `WANDB_API_KEY` to Colab Secrets and grant
   notebook access. Qwen's public weights do not normally require a token.
4. Choose **Run all**, upload the Sprint 1 zip, and authorize the Google Drive
   mount. Setup uses `uv sync --frozen --extra gpu --python 3.12` in a separate
   environment; subprocess execution avoids notebook import/restart conflicts.
5. The notebook detects GPU/VRAM/CUDA, runs CPU tests and the official-tokenizer
   contract, then performs **two optimizer steps**, validation, and checkpoints.
   It evaluates base and adapter in separate processes on the same test split.
6. Inspect `/content/drive/MyDrive/AdaptForge/<RUN_NAME>-smoke/`. Confirm
   `manifest.json` has `status=completed`, `smoke_only=true`; inspect adapter,
   checkpoints, and `evaluation/{base,fine_tuned,comparison}.json` plus CSVs.
   These synthetic arithmetic results are plumbing evidence only.
7. For a real run, put licensed, independently held-out data at
   `MyDrive/AdaptForge/private_data/splits/{train,validation,test}.jsonl` and a
   reviewed config at `MyDrive/AdaptForge/experiment.json`. Set `RUN_LONG=True`.
   W&B requires `report_to: "wandb"`; set `WANDB_PROJECT` and the API key secret.
   Use `WANDB_MODE=offline` for local logging and deliberate later sync.
8. Run only the final training cell after smoke review. Evaluate the resulting
   adapter using the commands below and its own untouched test data. Keep test
   feedback out of model selection; use validation for selection.

All run artifacts/checkpoints go to Drive, outside `/content` ephemeral storage.
Large model downloads and the environment remain ephemeral. Runtime eviction can
lose progress since the last periodic checkpoint. Drive writes can be slow and
are not guaranteed during abrupt disconnects; verify checkpoint completeness.
A failed smoke can be retried with a fresh `RUN_NAME`. To resume the two-step
smoke explicitly use the training CLI with both `--smoke` and `--resume`.

## Data contract and contamination

```json
{"id":"example-001","messages":[{"role":"user","content":"Return only JSON: 2 + 3"},{"role":"assistant","content":"{\"answer\":5}"}],"required_keys":["answer"]}
```

Each JSONL row needs a unique ID and alternating user/assistant text turns;
an optional initial system turn is allowed. The last turn is the reference.
`required_keys` enables JSON object/key validity checks; absent means unscored,
not invalid. Training supervises the **final assistant answer only** when
assistant-only loss is enabled; earlier turns are context. Reserved Qwen chat
delimiters in content are rejected. Examples with no target tokens after
truncation fail instead of silently yielding zero training loss.

`split` sorts IDs, seed-shuffles, and creates roughly 80/10/10 train/validation/test
splits. Normalized Unicode/case/whitespace prompt hashes and IDs must be unique
within and across splits. Split metadata includes counts and content hashes.
Add `source_id` to every row to keep entire source documents/task families
together during splitting; source overlap is also rejected across provided
split files. With source groups, proportions apply to group counts and row
counts may differ. These checks **do not detect semantic paraphrases or infer
unlabeled document relationships**. Perform semantic deduplication separately.
The automatic ungrouped random split is for already independent examples. Training revalidates
all three splits and never trains or validates on the test split.

Migrate the provided starter format:

```bash
uv run adaptforge migrate provenance/starter_example.jsonl artifacts/migrated.jsonl
uv run adaptforge validate artifacts/migrated.jsonl
```

The starter example contains only one row; it cannot form three useful splits.
The 40-row synthetic fixture exists only for tests and GPU smoke runs.

## Training and recovery

```bash
uv sync --frozen --extra gpu --python 3.12
uv run --frozen --extra gpu adaptforge train --config configs/qwen3_4b.json --data artifacts/smoke-splits --output /persistent/experiment-smoke --smoke
uv run --frozen --extra gpu adaptforge train --config /persistent/config.json --data /persistent/splits --output /persistent/run-001
# Restart an interrupted run from its latest COMPLETE periodic checkpoint:
uv run --frozen --extra gpu adaptforge train --config /persistent/run-001/config.resolved.json --data /persistent/splits --output /persistent/run-001 --resume /persistent/run-001/checkpoints/checkpoint-20
```

Model loading resolves the model revision to an immutable HF commit and records
it in `config.resolved.json`. It uses the official `Qwen/Qwen3-4B` tokenizer and
unmodified chat template, dynamic 4-bit loading, PEFT adapters on attention/MLP
projections, gradient checkpointing, and TRL SFT. Loss masking checks exact token
prefix alignment against that official template with thinking disabled. It
fails closed if alignment changes. It does not substitute generic delimiters.

BF16 is selected when the GPU supports it, otherwise FP16. Batch size starts at
one, with gradient accumulation; optimizer is 8-bit AdamW. OOM updates the durable
manifest and stops. Shorten context/rank in a **new** experiment; there is no
hidden batch reduction or automatic changed-config resume. Resumption requires
the same data/config fingerprint and a checkpoint within that run; periodic
Trainer checkpoints contain optimizer, scheduler, and RNG state. Only the final
adapter is insufficient for exact training resumption.

The seed, dataset hashes, package source hash, configuration, hardware and installed packages are
recorded. GPU kernels and different hardware/library versions can still prevent
bitwise determinism. A moving `main` is for the first resolution only; reproduce
with the saved immutable configuration and identical `uv.lock` and source.
The delivered config already pins Qwen3-4B revision
`1cfa9a7208912126459214e8b04321603b3df60c`, used by the actual CPU tokenizer tests.

## Evaluation and regression gate

```bash
uv run --frozen --extra inference adaptforge evaluate --config /persistent/run-001/config.resolved.json --test /persistent/splits/test.jsonl --output /persistent/eval --label base --quantized
uv run --frozen --extra inference adaptforge evaluate --config /persistent/run-001/config.resolved.json --test /persistent/splits/test.jsonl --output /persistent/eval --label fine_tuned --adapter /persistent/run-001/adapter --quantized
uv run adaptforge compare /persistent/eval/base.json /persistent/eval/fine_tuned.json /persistent/eval
```

Generation is greedy with a fixed seed and token budget; both sides use the same
quantization, base revision, tokenizer/template, test content and decoding.
Reports include per-case references/predictions, normalized exact-match task
accuracy, optional JSON object/required-key validity, elapsed generation latency,
aggregate output tokens/second, and peak PyTorch allocated GPU bytes. Ollama
reports memory as null because it does not expose allocator peaks. JSON and CSV
are suitable for dashboards. `compare` returns a nonzero exit code for accuracy
or structured-validity regressions (default tolerance zero) and records cases that lost correctness.
It also includes base/tuned structured validity and performance summaries.

Exact match is a narrow task metric, unsuitable for grading free-form prose.
JSON key validity is not JSON Schema validation or semantic correctness. Add
task-specific scorers and licensed evaluation suites before making quality
claims. Timing includes prefill and generation, excludes model loading and
tokenization, has no warmup, and is sensitive to hardware/load. Peak allocated
memory is not total GPU resident memory. Seeds reproduce inputs/decoding
settings; elapsed time and throughput are inherently variable.

`InferenceAdapter` also has a local Ollama implementation. It sends chat messages
to a user-configured server with greedy decoding. Verify the imported Ollama
model embeds the official template; do not assume HF/Ollama numerical parity.
The default local Transformers backend can run quantized inference on the RTX
4070 laptop if the actual available VRAM/context fits. No inference outcome on
that laptop has been validated in this sprint.

## Optional publication

Set `HF_TOKEN` as an environment secret. Do not place it in JSON, notebooks or Git.
Create public aggregate metadata with **exactly** these fields:
`dataset_name`, `license`, `source`, `train_count`, `validation_count`, `test_count`.
Avoid private source paths/names in the public fields. Stage first for inspection:

```bash
uv run --extra publish adaptforge publish --run /persistent/run-001 --release artifacts/release-001 --metadata /persistent/public-metadata.json
# A NEW staging directory is required for every invocation:
uv run --extra publish adaptforge publish --run /persistent/run-001 --release artifacts/release-002 --metadata /persistent/public-metadata.json --repo YOUR_USER/YOUR_ADAPTER --upload
```

Only completed non-smoke runs may be staged. The allowlist includes adapter
weights, tokenizer assets, a model card, resolved experiment configuration and
aggregate dataset metadata. Raw data, private manifests, logs, environment
secrets and checkpoints are excluded. Upload is disabled without `--upload`;
repositories are private by default. `--public` explicitly permits a public
destination; it does not automatically change an existing repository's visibility.
No upload has been performed during implementation.

## Space and optional GGUF

`space/` is an independent Gradio Space with a locked dependency set and no
mandatory hosted GPU. It starts in an unavailable state until a user configures
a reachable inference gateway. See its README for offline behavior and secrets.
It has not been deployed. A Space cannot directly reach a laptop's localhost.

GGUF conversion is optional and requires **merged full Qwen3 weights**, sufficient
RAM/disk, and a user-selected built llama.cpp checkout. Use a separate process to
merge the PEFT adapter with the exact base revision in BF16/FP16 (quantized LoRA
weights cannot simply be renamed into GGUF). The CLI checks model type,
converter-advertised `Qwen3ForCausalLM` support, tooling and free disk before
calling conversion/quantization; it never downloads or builds tools implicitly.

```bash
uv run adaptforge export-gguf --merged-model /persistent/merged --llama-cpp /tools/llama.cpp --output /persistent/qwen3-adapted.gguf --enable-export
```

Record the llama.cpp commit and repeat held-out evaluation on the exported model.
Merged-weight export, conversion and Ollama numerical parity remain unvalidated.

## Limitations, cost and status

CPU checks verify orchestration, dataset integrity, masking contracts with test
doubles, report serialization, regression gates and disabled external actions.
The optional real-tokenizer test is skipped unless explicitly enabled. CI runs
the CPU suite on Windows/Linux and Python 3.11–3.13; remote CI has not yet run.
GPU training, checkpoint resume, actual model inference, live HF publishing,
Space deployment and GGUF conversion require execution before being called
validated. See `docs/VALIDATION.md` and `docs/CUDA_COMPATIBILITY.md`.

Colab Pro compute units, paid GPU allocation, model downloads, Drive storage,
W&B storage and optional HF hosting can consume quota or incur costs. No fixed
runtime, dollar cost, GPU availability or model improvement is promised. Start
with the two-step smoke, inspect memory, then increase steps/context gradually.
HF Pro does not imply continuous GPU hosting. This code provisions no paid
resources. DPO, GRPO, multimodal work and production scaling are out of scope.

Primary references used to implement the API contracts:
[Qwen training guide](https://github.com/QwenLM/Qwen3/blob/main/docs/source/training/unsloth.md),
[official tokenizer template](https://huggingface.co/Qwen/Qwen3-4B/blob/main/tokenizer_config.json),
[TRL 0.24 SFT](https://huggingface.co/docs/trl/v0.24.0/en/sft_trainer),
[Unsloth installation](https://unsloth.ai/docs/get-started/install).
