---
title: Tunera
emoji: 🎛️
colorFrom: blue
colorTo: green
sdk: docker
app_port: 7860
app_file: app.py
pinned: false
license: apache-2.0
---

# Tunera

CPU tools share the training package's configuration, dataset and scoring code:
plan pinned Qwen3 experiments, validate JSONL and preview reproducible splits,
and score visitor-supplied saved responses. No training or inference is started
by these tools. Use public or synthetic inputs only; inputs are processed on this
shared server. Limits: 250 cases and 256 KB per text input. Dataset and response
tools do not write submitted data to files. Gradio may keep temporary session
state; this is not a private data upload service.

Project: https://jacobroutzong.dev/projects/tunera/
Source download: https://jacobroutzong.dev/downloads/tunera-ai-0.3.1.zip

Deploy this directory as a **separate** Hugging Face Docker Space. It starts on
CPU without downloading or loading a model. Set `TUNELEDGER_ENDPOINT` to your
reachable Ollama `/api/chat` service origin and `TUNELEDGER_OLLAMA_MODEL` to an
explicitly imported model to enable requests. An unset endpoint returns an
honest unavailable message. The local laptop endpoint is not reachable from a
hosted Space without a deliberately configured secure gateway.

Do not expose an unauthenticated laptop server publicly. For a private gateway,
set Space secret `TUNELEDGER_ENDPOINT_TOKEN` and enforce bearer authentication
at that gateway. Ollama itself does not implement this gateway authentication.
No always-on GPU is assumed or provisioned. Network timeout/offline state is
shown as unavailable; requests are bounded to 128 output tokens and serialized.
Verify the imported model's official chat template before deployment.

Install `requirements.lock` on Python 3.11–3.13 for the resolved transitive set;
the Docker build installs the hash-pinned lock directly. No trained model or
benchmark is bundled. Upload is a separate user-controlled deployment action.
