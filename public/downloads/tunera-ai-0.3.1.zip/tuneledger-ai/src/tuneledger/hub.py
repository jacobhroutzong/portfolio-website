"""Private experiment storage, distinct from curated public releases."""
import re
from pathlib import Path


def authenticated_api(repo_id, owner='jacobroutzong'):
    from huggingface_hub import HfApi
    if not re.fullmatch(r'[\w.-]+/[\w.-]+', repo_id) or repo_id.split('/')[0] != owner:
        raise ValueError('Repository must belong to the intended owner')
    api = HfApi()
    if api.whoami()['name'] != owner:
        raise ValueError('Authenticated Hugging Face account does not match intended owner')
    return api


def sync_run(run, repo_id, owner='jacobroutzong', enabled=False):
    if not enabled:
        raise ValueError('Hub synchronization requires explicit authorization')
    path = Path(run)
    api = authenticated_api(repo_id, owner)
    api.create_repo(repo_id, repo_type='model', private=True, exist_ok=True)
    if not api.repo_info(repo_id).private:
        raise ValueError('Experiment storage must be private')
    return api.upload_folder(repo_id=repo_id, folder_path=str(path),
        allow_patterns=['manifest.json', 'config.resolved.json', 'events.jsonl',
                        'latest_checkpoint.json', 'training_metrics.json', 'job.json', 'pipeline.json', 'adapter/*',
                        'checkpoints/checkpoint-*/*', 'evaluation/*.json', 'evaluation/*.csv'],
        ignore_patterns=['**/.env*', '**/*.jsonl'],
        commit_message='Save private TuneLedger experiment state')


def restore_run(repo_id, revision, destination, owner='jacobroutzong', enabled=False):
    if not enabled:
        raise ValueError('Hub restore requires explicit authorization')
    if not re.fullmatch('[0-9a-f]{40}', revision):
        raise ValueError('Restore requires an immutable Hub commit')
    dest = Path(destination)
    if dest.exists() and any(dest.iterdir()):
        raise ValueError('Restore destination must be empty')
    api = authenticated_api(repo_id, owner)
    if not api.repo_info(repo_id).private:
        raise ValueError('Experiment storage must be private')
    from huggingface_hub import snapshot_download
    snapshot_download(repo_id, revision=revision, local_dir=str(dest),
        allow_patterns=['manifest.json', 'config.resolved.json', 'latest_checkpoint.json',
                        'checkpoints/*', 'adapter/*', 'training_metrics.json'])
    from .checkpoints import latest_checkpoint
    return latest_checkpoint(dest)
