"""Create a source-only Colab handoff zip, excluding data and runtime artifacts."""
import argparse
import os
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE = {".venv", ".uv-cache", "__pycache__", "artifacts", "private_data", "dist", ".git", "wandb"}
ROOT_FILES = {'pyproject.toml', 'uv.lock', 'README.md', 'LICENSE', '.gitignore', '.dockerignore', '.env.example'}
SOURCE_DIRS = {'src', 'tests', 'configs', 'docs', 'scripts', 'space', 'notebooks', 'deployment', 'provenance', '.github'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED) as archive:
        paths = []
        for directory, dirs, files in os.walk(ROOT):
            dirs[:] = sorted(d for d in dirs if d not in EXCLUDE)
            paths.extend(Path(directory)/name for name in files)
        for path in sorted(paths):
            relative = path.relative_to(ROOT)
            if path.is_symlink() or not path.is_file() or set(relative.parts) & EXCLUDE or path.resolve() == args.output.resolve():
                continue
            if relative.as_posix() not in ('data/smoke.jsonl', 'data/benchmarks/engineering_acceptance.jsonl') and relative.parts[0] not in SOURCE_DIRS and relative.as_posix() not in ROOT_FILES:
                continue
            if path.suffix in ('.key', '.pem', '.pt', '.pth', '.pkl', '.zip'):
                continue
            if path.name.startswith(".env") and path.name != ".env.example":
                continue
            if path.suffix in (".safetensors", ".gguf", ".bin", ".pyc"):
                continue
            # Fixed timestamps make repeated handoff archives byte-identical.
            info = zipfile.ZipInfo("tuneledger-ai/" + relative.as_posix(), date_time=(2026, 10, 18, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    print(args.output.resolve())


if __name__ == "__main__":
    main()
