"""Conversation validation, prompt-level contamination checks and seeded splits."""
import json
import random
import re
import unicodedata
from pathlib import Path
from .artifacts import digest, write_json


def normalize(text):
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", text).casefold()).strip()


def prompt_key(row):
    return digest([normalize(m["content"]) for m in row["messages"] if m["role"] == "user"])


def validate(rows):
    if not isinstance(rows, list) or not rows:
        raise ValueError("Dataset must be a nonempty list")
    seen_ids, seen_prompts = set(), set()
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("id"), str) or not row["id"]:
            raise ValueError("Every row requires a nonempty string id")
        if "source_id" in row and (not isinstance(row["source_id"], str) or not row["source_id"].strip()):
            raise ValueError("source_id must be a nonempty string")
        if row.get('scorer', 'exact_match') not in ('exact_match', 'json_exact'):
            raise ValueError('Unknown scorer; use exact_match or json_exact')
        if 'category' in row and (not isinstance(row['category'], str) or not row['category'].strip()):
            raise ValueError('Category must be nonempty text')
        if "required_keys" in row and (not isinstance(row["required_keys"], list) or
                not all(isinstance(key, str) and key for key in row["required_keys"])):
            raise ValueError("required_keys must be a list of nonempty strings")
        messages = row.get("messages")
        if not isinstance(messages, list) or len(messages) < 2:
            raise ValueError("Each row requires a user/assistant conversation")
        roles = []
        for m in messages:
            if not isinstance(m, dict) or set(m) != {"role", "content"}:
                raise ValueError("Messages require exactly role and content")
            if not isinstance(m["content"], str) or not m["content"].strip():
                raise ValueError("Message content must be nonempty text")
            if "<|im_start|>" in m["content"] or "<|im_end|>" in m["content"]:
                raise ValueError("Reserved chat delimiters in dataset content")
            roles.append(m["role"])
        if roles[0] == "system":
            roles = roles[1:]
        if not roles or len(roles) % 2 or roles != [r for _ in range(len(roles)//2) for r in ("user", "assistant")]:
            raise ValueError("Expected alternating user/assistant turns ending in assistant")
        if row["id"] in seen_ids or prompt_key(row) in seen_prompts:
            raise ValueError("Duplicate id or normalized prompt contamination")
        seen_ids.add(row["id"])
        seen_prompts.add(prompt_key(row))
    return rows


def read_jsonl(path):
    return validate([json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()])


def check_contamination(splits):
    ids, prompts, sources = set(), set(), set()
    for name, rows in splits.items():
        validate(rows)
        for row in rows:
            key = prompt_key(row)
            if row["id"] in ids or key in prompts:
                raise ValueError(f"Cross-split contamination in {name}")
            ids.add(row["id"])
            prompts.add(key)
        current_sources = {row["source_id"] for row in rows if "source_id" in row}
        if current_sources & sources:
            raise ValueError(f"Cross-split source contamination in {name}")
        sources.update(current_sources)


def split_dataset(rows, seed=42):
    validate(rows)
    if len(rows) < 10:
        raise ValueError("Need at least 10 unique conversations for three splits")
    if any("source_id" in row for row in rows) and not all("source_id" in row for row in rows):
        raise ValueError("Provide source_id on every row or none")
    groups = {}
    for row in sorted(rows, key=lambda r: r["id"]):
        groups.setdefault(row.get("source_id", row["id"]), []).append(row)
    ordered = [groups[key] for key in sorted(groups)]
    if len(ordered) < 3:
        raise ValueError("Need at least three independent source groups")
    random.Random(seed).shuffle(ordered)
    n = max(1, len(ordered)//10)
    def flatten(parts):
        return [row for group in parts for row in group]
    splits = {"test": flatten(ordered[:n]), "validation": flatten(ordered[n:2*n]), "train": flatten(ordered[2*n:])}
    check_contamination(splits)
    return splits


def save_splits(splits, directory):
    check_contamination(splits)
    path = Path(directory)
    path.mkdir(parents=True, exist_ok=True)
    for name, rows in splits.items():
        (path / f"{name}.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")
    write_json(path / "metadata.json", {name: {"count": len(rows), "sha256": digest(rows)} for name, rows in splits.items()})


def load_splits(directory):
    splits = {name: read_jsonl(Path(directory)/f"{name}.jsonl") for name in ("train", "validation", "test")}
    check_contamination(splits)
    return splits
