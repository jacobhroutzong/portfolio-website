# Validation record

## Tunera v1 model research freeze

Qwen3-4B QLoRA remains the default. Qwen3.5-2B BF16 LoRA remains an
experimental option with its own pinned environment. The small synthetic GPU
acceptance tests below verified training and recovery for both recipes.

The separate 120-case promotion benchmark retained three complete arms:
Qwen3-4B base (71/120), Qwen3.5-2B base (70/120), and Qwen3.5-2B
adapter (66/120). Each result is the semantic success count on the frozen
synthetic suite. The Qwen3-4B adapter arm and its reload check are incomplete.
There is no matched comparison between the two adapters, so the partial
results do not support a definitive model ranking.

The first upload through the Colab Contents endpoint returned HTTP 500.
The next run produced the three retained arms, but its complete output
bundle could not be recovered. A subsequent kernel transfer stopped at
chunk 238 of 337 with HTTP 404. The final evaluation-only attempt used a verified
private Hub download path, but Colab crashed before it delivered a results
bundle. Its accounting recorded zero active assignments and zero ongoing
usage after cleanup. The exact failure stage of that last attempt is not
recorded in the retained bundle.

The sealed checkpoints, training evidence, frozen benchmark, and three
completed arms are preserved in the local research archive. Further GPU
attempts and model comparisons are deferred beyond v1. The portfolio
release is assessed on its workbench, dataset and scoring workflows.

## Release verification — 2026-11-07

- Qwen3-4B QLoRA passed GPU acceptance on a Colab Pro NVIDIA L4 through the
  official browser MCP bridge. The test kept the default model, revision, rank,
  and context, with 20 updates and checkpoint/evaluation intervals of five.
  A fresh process resumed from sealed checkpoint 15 and reached step 20.
  All 15 files in the final checkpoint verified. Both the base and recovered
  adapter scored 4/4 for exact match and structured validity on the same four
  held-out synthetic cases. The regression gate passed.
- The acceptance run exposed two defects. Training now tells Unsloth to load
  the exact model repository and revision. The frozen environment also pins
  TorchAO 0.15.0 to match PyTorch 2.9.1 for paired evaluation. Resume older
  checkpoints with the source and frozen environment that created them.
- All six CPU workflow combinations passed locally with uv 0.13.0 on Windows
  and Ubuntu 24.04 (WSL), using Python 3.11, 3.12 and 3.13. Each completed
  the corrected frozen install and unit suite (51 passed, 4 optional integration tests
  skipped), validated both bundled datasets (40 and 12 rows), and built the
  source distribution and wheel. GitHub-hosted CI was not run for this update.
- Qwen3-4B QLoRA remains the default. The separate experimental Qwen3.5-2B
  BF16 LoRA reference recipe completed 20 updates on a Colab Pro L4 and
  recovered from checkpoint 15 in a fresh process.
  The recovered run peaked at 4.33 GiB allocated. Paired exact-match evaluation
  on four held-out synthetic cases measured 0/4 for the base and 4/4 for the
  recovered adapter. The regression gate passed. See the
  [experimental recipe and run evidence](QWEN35_EXPERIMENT.md).
- A second Qwen3.5-2B run matched Qwen3-4B's rank, context, optimizer step
  count, seed, held-out cases, and decoding limit on the same L4. Both recipes
  passed recovery and scored 4/4 with the recovered adapter. Qwen3-4B and
  Qwen3.5-2B respectively took 47.4 s and 105.9 s inside the initial Trainer
  run. Recovered-adapter generation averaged 1.35 s and 0.87 s per case,
  with 2.67 GiB and 4.19 GiB of peak allocated memory during generation.
  The measured training, recovery, and evaluation subprocesses totaled 226 s
  and 209 s. At the displayed 1.94 included compute units/hour, those phases
  correspond to about 0.12 and 0.11 units. Setup, retries, and idle time are
  excluded, and model-cache state differed between runs. This fixture checks
  operation and does not establish cost or quality parity for larger workloads.
- The production workbench passed the Crucible fixture replay, including
  11 scoring and report fields, all eight legacy redirects, and historical
  report recovery. The standalone portfolio UI was retired after approval.
  The original scorer remains the production backend.
- The source ZIP contains the default and experimental recipes, separate
  dependency locks, tests and documentation. It excludes training outputs,
  model weights and private datasets.

## Historical verification — 2026-10-28

The active project is now named TuneLedger (Python package/CLI: `tuneledger`).
The public CPU workspace adds bounded configuration planning, dataset validation
and saved-output scoring using the package core. Four additional tests cover
these tools. The expanded tokenizer-enabled suite now contains 50 tests.

This section covers the October verification. Historical attachment claims
remain in `provenance/SPRINT1_VALIDATION.md`.

## Inputs and scope

Restored the individually attached source, configs, tests, notebook, smoke data,
Space, dependency locks, packaging script and docs. `download (4)` was a gitignore,
not a ZIP. No base v0.3.1 ZIP or the three requested handoff/policy documents was
present. The supplied starter-archive checksum is preserved but not reverified.

Added provider adapters, offline plans, HF Jobs orchestration, Colab scripting,
a training container recipe, event tracking, checksummed checkpoint recovery,
private Hub persistence, paired process-isolated evaluation, JSON scoring,
category metrics, a synthetic acceptance fixture, Space staging and portfolio
embed. Qwen3-family registration shares one training implementation; Qwen3.5 and
gpt-oss remain blocked.

## Actual checks

Windows, Python 3.12.14, uv 0.13.0. Local RTX 4070 Laptop GPU: 8,188 MiB total
VRAM, driver 621.01. Native Windows Unsloth training is outside the Linux extra.

- Baseline: 24 tests discovered, 22 passed, two tokenizer checks skipped.
- Expanded suite: **46/46 tests passed**, including both real-tokenizer tests,
  in the isolated tokenizer environment with source imports and HF offline mode.
  The standard CPU suite skips those two optional integration tests.
- Official Qwen3-4B tokenizer: two integration tests passed with Transformers
  4.57.6, Jinja2 3.1.6 and revision
  `1cfa9a7208912126459214e8b04321603b3df60c`. Covers final-answer masking, all
  40 smoke examples and system/multiturn context. No model weights downloaded.
- Frozen CPU installation succeeded; temporary/cache paths redirected to artifacts.
- Offline lock consistency check passed, 130 packages after version update.
- Split/validate and Colab dry-run CLI passed: 40 rows split 32/4/4.
- SDK job arguments checked against the installed HF Hub 0.36.2 signature.
- Read-only authentication verified HF `jacobroutzong`, GitHub `jacobhroutzong`.
  Tokens were not copied into source, reports or command arguments.

Recovery, OOM and storage-failure tests execute real orchestration with explicit
CPU doubles for model, Trainer and CUDA. They validate lifecycle management,
not optimizer math, convergence, measured GPU memory or model quality.

## Pending execution and approval

No Colab MCP tools are exposed here. No GPU training, real optimizer recovery,
model generation, W&B service, live HF Job, Hub upload/restore, training container,
or GGUF export was executed. CPU publication was separately authorized after
these infrastructure checks; see the publication section below. Remote CI is configured
but has not run. Local CPU UI and packaging checks are recorded below.

No billable job or trained-model artifact was created. Additional GPU charges and
public model publishing require approval. Connecting Colab and
mounting Drive need user consent. Real quality evaluation needs licensed task data.

## Additional completed checks

- Local Gradio 5.49.1 app launched on 127.0.0.1, served its configuration and
  evaluation UI, and returned the expected unavailable-inference response.
  Public sharing was disabled and the server was closed afterward. A sandbox
  socketpair restriction required running this localhost check outside the socket
  sandbox; this was not an application defect.
- Source and wheel builds passed. A clean, dependency-free environment installed
  the wheel and validated all 40 smoke rows successfully.
- Python compilation and Ruff undefined-name/invalid-syntax checks passed.
- The 12-case acceptance dataset validated; paired-pipeline planning and Space
  staging executed without network writes or GPU allocation.
- Read public model metadata and saved pinned configurations for Qwen3 0.6B,
  1.7B and 8B. Their GPU behavior and tokenizer contracts remain unvalidated.
- Source archive, source distribution and wheel contents inspected: no virtual
  environments, runtime caches, raw private data, model/checkpoint binaries or
  environment secrets included. The wheel contains the package and distribution
  metadata only.

## TuneLedger rename and CPU publication

The user approved public portfolio publication and explicitly approved the public
CPU Space. Active package, CLI, environment keys, source imports, notebook and
deployment assets were renamed; original input provenance retains its names.
All 50 tests passed with the real tokenizer enabled after the rename and public
demo additions. Local Gradio startup/HTTP and static checks passed again.
The public demo runs CPU validation/planning/scoring only, using free cpu-basic
hardware. It installs the dependency lock in a Docker image, after the managed
Gradio builder failed to resolve its relative requirements.lock include.
