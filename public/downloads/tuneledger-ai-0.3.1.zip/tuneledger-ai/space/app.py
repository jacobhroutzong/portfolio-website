"""CPU-only UI; user-configured inference gateway may be offline."""
import json
import os
import urllib.error
import urllib.request
from pathlib import Path
import gradio as gr
from demo_core import EXAMPLES, REVISIONS, plan_run, validate_data, score_outputs


def respond(message, history):
    endpoint = os.environ.get("TUNELEDGER_ENDPOINT")
    model = os.environ.get("TUNELEDGER_OLLAMA_MODEL")
    if not endpoint or not model:
        return "Inference is unavailable. Configure a model endpoint when compute is available."
    if len(message) > 8000:
        return "Please limit your message to 8,000 characters."
    payload = {"model": model, "messages": [{"role": "user", "content": message}], "stream": False,
               "think": False, "options": {"temperature": 0, "seed": 42, "num_predict": 128}}
    headers = {"Content-Type": "application/json"}
    if os.environ.get("TUNELEDGER_ENDPOINT_TOKEN"):
        headers["Authorization"] = "Bearer " + os.environ["TUNELEDGER_ENDPOINT_TOKEN"]
    try:
        req = urllib.request.Request(endpoint.rstrip("/")+"/api/chat", json.dumps(payload).encode(), headers)
        with urllib.request.urlopen(req, timeout=90) as response:
            return json.load(response)["message"]["content"]
    except (urllib.error.URLError, TimeoutError, ValueError, KeyError):
        return "Inference is currently unavailable. Try again when the configured compute is online."


with gr.Blocks(title='TuneLedger AI') as demo:
    gr.Markdown('# TuneLedger\n### Every experiment leaves a trail.\n'
                'Plan QLoRA runs, validate conversation data, and inspect saved outputs using the same CPU core as the training CLI. '
                '**GPU training and model benchmarks are pending.** These tools never start compute.\n\n'
                '[Project walkthrough](https://jacobroutzong.dev/projects/tuneledger/) · '
                '[Download source](https://jacobroutzong.dev/downloads/tuneledger-ai-0.3.1.zip)')
    with gr.Tab('Plan an experiment'):
        gr.Markdown('Choose a pinned Qwen3 model and inspect the resolved settings. Hardware fit still requires a GPU smoke test.')
        with gr.Row():
            size = gr.Dropdown(list(REVISIONS), value='4B', label='Qwen3 model')
            context = gr.Slider(128, 4096, value=512, step=128, label='Maximum context tokens')
        with gr.Row():
            rank = gr.Slider(4, 64, value=16, step=4, label='LoRA rank')
            steps = gr.Slider(2, 1000, value=100, step=1, label='Optimizer steps')
        plan = gr.JSON(value=plan_run('4B', 512, 16, 100), label='Experiment plan')
        gr.Button('Build plan', variant='primary').click(plan_run, [size, context, rank, steps], plan)
    with gr.Tab('Validate a dataset'):
        gr.Markdown('Use public or synthetic examples only. This shared demo processes inputs on the Space server. '
                    'Limit: 250 cases / 256 KB. Source grouping and normalized duplicate checks do not detect semantic paraphrases.')
        cases = gr.Textbox(value=EXAMPLES, lines=12, label='Conversation cases (JSONL)')
        validation = gr.JSON(label='Validation and seeded split preview')
        gr.Button('Validate data', variant='primary').click(validate_data, cases, validation)
    with gr.Tab('Score saved outputs'):
        gr.Markdown('Scores supplied text against reference cases. This performs no inference; these are not measured model benchmarks.')
        scoring_cases = gr.Textbox(value=EXAMPLES, lines=7, label='Reference cases (JSONL)')
        saved_outputs = gr.Textbox(lines=6, label='Predictions: JSON object mapping case IDs to response strings',
                                  placeholder='{"case-01": "{\\"result\\": 3}", ...}')
        scores = gr.JSON(label='Case-level report')
        gr.Button('Score outputs', variant='primary').click(score_outputs, [scoring_cases, saved_outputs], scores)
    with gr.Tab('Evaluation'):
        results = Path(__file__).parent / 'benchmarks.json'
        gr.JSON(json.loads(results.read_text(encoding='utf-8')) if results.exists()
                else {'status': 'No measured GPU benchmark results available'})
    with gr.Tab('Optional inference'):
        gr.ChatInterface(respond, type="messages", title="Configured model gateway",
            description="Unavailable until a separate inference gateway is configured. Requests are independent.")
if __name__ == "__main__":
    demo.queue(default_concurrency_limit=1, max_size=8).launch()
