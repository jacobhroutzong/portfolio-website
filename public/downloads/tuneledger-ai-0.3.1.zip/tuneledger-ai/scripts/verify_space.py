"""Local-only Space startup/HTTP/offline behavior acceptance check."""
import json
import os
from pathlib import Path
import runpy
import socket
import sys
import urllib.request


def main():
    os.environ['GRADIO_ANALYTICS_ENABLED'] = 'False'
    for key in ('TUNELEDGER_ENDPOINT', 'TUNELEDGER_OLLAMA_MODEL', 'TUNELEDGER_ENDPOINT_TOKEN'):
        os.environ.pop(key, None)
    source = Path(__file__).resolve().parents[1] / 'space'
    sys.path.insert(0, str(source))
    app = runpy.run_path(str(source / 'app.py'))
    assert 'unavailable' in app['respond']('hello', [])
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    demo = app['demo']
    try:
        demo.queue(default_concurrency_limit=1, max_size=8).launch(
            server_name='127.0.0.1', server_port=port, share=False,
            prevent_thread_lock=True, quiet=True)
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/config', timeout=15) as response:
            config = json.load(response)
        assert config['title'] == 'TuneLedger AI'
        assert any(c['type'] == 'json' for c in config['components'])
        print('PASS: localhost Space starts, serves configuration, exposes evaluation UI, and reports offline inference')
    finally:
        demo.close()


if __name__ == '__main__':
    main()
