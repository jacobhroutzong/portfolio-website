# Tunera 0.3.1

Previously called TuneLedger (and AdaptForge AI in the original inputs). The
public name is now Tunera. The Python package and CLI remain `tuneledger` so
existing scripts keep working. Historical input documents retain their names.

A reproducible fine-tuning laboratory with provider-independent QLoRA training,
dataset checks, recoverable experiments, paired evaluation and deployment staging.
**GPU acceptance is pending. No trained model or improvement claim is included.**

This reconstructs the individually attached Sprint 1 source files and adds the
infrastructure requested in chat. The base v0.3.1 ZIP and its
`START_HERE_CODEX.md`, `COMPUTE_POLICY.md` and `CODEX_AUTOMATION_HANDOFF_v3.md`
were unavailable. Exact conformance to those documents cannot be claimed.
Historical reports are in `provenance/`; current evidence is in
[VALIDATION](docs/VALIDATION.md).

## CPU setup and verification

Python 3.11–3.13, uv 0.13.0. Core imports are dependency-free; SDK contract tests
use the small `publish` extra. GPU imports are lazy.

```bash
uv sync --frozen --extra publish
uv run --frozen --extra publish python -m unittest discover -s tests -v
uv run --frozen --extra publish tuneledger doctor
uv run --frozen --extra publish tuneledger validate data/smoke.jsonl
uv run --frozen --extra publish tuneledger split data/smoke.jsonl artifacts/smoke-splits
uv run --frozen --extra publish tuneledger launch --provider colab --config configs/qwen3_4b.json --data artifacts/smoke-splits --output artifacts/proposed-smoke --smoke --plan-output artifacts/colab-plan.json
uv build
```

`launch` and `pipeline` plan by default. Local plans make no network requests and
allocate no GPU. `train` explicitly starts training. HF Jobs require execution
and cost-approval flags; public publication is separate. See
[compute policy](docs/COMPUTE_AND_APPROVALS.md).

Use frozen installs from the supplied complete optional dependency lock. Lock
resolution is not CUDA kernel validation. GPU installs target Linux/Python 3.12;
Windows CPU/inference is separate.

## Training and recovery

Prefer Colab Pro through Google's official MCP integration where supported.
No Colab MCP tools were exposed in this session. After connecting a runtime and
mounting Drive, one script installs dependencies and runs the smoke pipeline:

```bash
python scripts/run_colab.py --persistent /content/drive/MyDrive/TuneLedger --run qwen3-smoke-001 --execute
```

For a real run provide both `--config /persistent/experiment.json` and
`--data /persistent/splits` with licensed, independently held-out examples.
The default performs two optimizer steps and paired evaluation using synthetic
data, which verifies plumbing only. The notebook remains an optional fallback.

The same commands run inside a local Linux environment or a container:

```bash
uv sync --frozen --extra gpu --python 3.12
tuneledger pipeline --config configs/qwen3_4b.json --data /persistent/splits --output /persistent/run-001
# Execute only on an approved GPU runtime:
tuneledger pipeline --config configs/qwen3_4b.json --data /persistent/splits --output /persistent/run-001 --execute
tuneledger train --config /persistent/run-001/config.resolved.json --data /persistent/splits --output /persistent/run-001 --resume latest
tuneledger runs /persistent
```

Training uses Unsloth, TRL, official model/tokenizer revisions, 4-bit weights,
LoRA attention/MLP projections, gradient checkpointing, accumulation, an 8-bit
optimizer and hardware-selected BF16/FP16. Final-assistant masking proves token
prefix alignment with the official template and rejects truncated targets.
Qwen3-4B is primary; Qwen3 0.6B, 1.7B and 8B share the registered implementation.
All await GPU acceptance. Qwen3.5 and gpt-oss remain blocked scaffolds.

Runs record atomic manifests, resolved config, data/source hashes, package
versions, hardware, events and metrics. Checkpoints require model, optimizer,
scheduler and RNG state plus checksums. `--resume latest` ignores partial saves.
Config, data, code, Python/packages and precision must match. Abrupt eviction can
lose progress after the last persisted checkpoint; GPU determinism is not guaranteed.

HF Jobs adds immutable image/dataset/model revisions, timeouts, account checks,
status/log/cancel commands and private checkpoint persistence/recovery. Follow the
[deployment handoff](docs/DEPLOYMENT.md) for container builds and job specifications.

## Data and evaluation

```json
{"id":"case-001","messages":[{"role":"user","content":"Return only JSON: 2 + 3"},{"role":"assistant","content":"{\"answer\":5}"}],"required_keys":["answer"],"scorer":"json_exact","category":"arithmetic"}
```

Messages alternate user/assistant turns with an optional initial system message.
IDs and normalized user prompts must be unique. Optional `source_id` keeps whole
documents/families together; provide it on every row when grouping. Splits are
seeded and order-independent. Training revalidates all three splits and source
overlap. These checks do not detect semantic paraphrases or infer source groups.
The test split is never passed to the Trainer.

`required_keys` checks JSON object keys, not a full JSON Schema. `scorer` defaults
to normalized exact match; `json_exact` ignores object key order and preserves
value types. Malformed/duplicate-key JSON fails. `category` produces task-level
aggregates. Reports contain private references/predictions, exact and structured
metrics, generation latency, throughput and CUDA peak allocated memory.

The pipeline runs training, base inference and adapter inference in separate
processes. Paired reports require matching test data, revisions, seeds,
quantization and decoding. The comparison command fails on regressions.

```bash
tuneledger evaluate --config RUN/config.resolved.json --test data/benchmarks/engineering_acceptance.jsonl --output RUN/acceptance --label base --quantized
tuneledger evaluate --config RUN/config.resolved.json --test data/benchmarks/engineering_acceptance.jsonl --output RUN/acceptance --label fine_tuned --adapter RUN/adapter --quantized
tuneledger compare RUN/acceptance/base.json RUN/acceptance/fine_tuned.json RUN/acceptance
```

The 12-case engineering acceptance suite covers extraction, instruction following,
simple reasoning and multiturn context. It is a synthetic regression fixture,
not a standardized benchmark. Supply licensed domain suites before quality
claims. Exact match does not grade free-form prose. Timing excludes loading and
tokenization, has no warmup, and varies by hardware/load. Allocated memory is not
total GPU memory. No synthetic/test-double measurements are published as results.

## Release and portfolio

`publish` stages only completed non-smoke adapters with reviewed aggregate dataset
metadata. `--upload` is separate and private by default; `--public` is explicit.
Credentials remain in CLI/provider secret stores. Raw private runs and curated
public releases have separate allowlists.

```bash
tuneledger stage-space --output artifacts/space-release
python scripts/package_repo.py artifacts/TuneLedger_AI_0.3.1.zip
```

The CPU Gradio Space shows availability and evaluation status and can contact an
explicitly configured inference gateway. No paid Space hardware is provisioned.
The `/projects/tunera/` embed and full-screen fallback are prepared in
`deployment/portfolio-embed.html`. Link that page from the homepage Selected
projects and Projects listing. Public destinations are
[TuneLedger](https://jacobroutzong.dev/projects/tunera/) and its
[CPU Space](https://huggingface.co/spaces/jacobroutzong/tuneledger).

See [architecture](docs/ARCHITECTURE.md), [deployment](docs/DEPLOYMENT.md),
[CUDA compatibility](docs/CUDA_COMPATIBILITY.md) and
[current verification](docs/VALIDATION.md) for operational details and limits.
