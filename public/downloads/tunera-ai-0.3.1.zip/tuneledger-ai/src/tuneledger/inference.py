"""Interchangeable generation backends. Greedy decoding, explicit output limits."""
import json
import time
import urllib.request
from dataclasses import asdict, dataclass
from typing import Protocol


@dataclass
class Generation:
    text: str
    output_tokens: int
    latency_seconds: float
    peak_gpu_bytes: int | None = None

    def to_dict(self):
        return asdict(self)


class InferenceAdapter(Protocol):
    def generate(self, messages: list[dict], max_new_tokens: int = 128) -> Generation: ...


class TransformersAdapter:
    def __init__(self, model_id, revision, adapter_path=None, quantized=False, seed=42):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig, set_seed
        set_seed(seed)
        if quantized and not torch.cuda.is_available():
            raise RuntimeError("4-bit inference requires CUDA")
        self.torch = torch
        self.tokenizer = AutoTokenizer.from_pretrained(model_id, revision=revision, trust_remote_code=False)
        if not self.tokenizer.chat_template:
            raise ValueError("Official tokenizer has no chat template")
        kwargs = {"quantization_config": BitsAndBytesConfig(load_in_4bit=True,
            bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True,
            bnb_4bit_compute_dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16)} if quantized else {}
        self.model = AutoModelForCausalLM.from_pretrained(model_id, revision=revision,
            torch_dtype="auto", device_map="auto", trust_remote_code=False, **kwargs)
        if adapter_path:
            from peft import PeftModel
            self.model = PeftModel.from_pretrained(self.model, adapter_path)
        self.model.eval()

    def generate(self, messages, max_new_tokens=128):
        torch = self.torch
        inputs = self.tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True,
            enable_thinking=False, return_tensors="pt", return_dict=True).to(self.model.device)
        gpu = torch.cuda.is_available() and any(p.device.type == "cuda" for p in self.model.parameters())
        if gpu:
            torch.cuda.synchronize()
            torch.cuda.reset_peak_memory_stats()
        start = time.perf_counter()
        with torch.inference_mode():
            output = self.model.generate(**inputs, do_sample=False, max_new_tokens=max_new_tokens,
                pad_token_id=self.tokenizer.eos_token_id)
        if gpu:
            torch.cuda.synchronize()
        elapsed = time.perf_counter()-start
        new = output[0, inputs["input_ids"].shape[-1]:]
        return Generation(self.tokenizer.decode(new, skip_special_tokens=True).strip(), len(new), elapsed,
                          torch.cuda.max_memory_allocated() if gpu else None)


class OllamaAdapter:
    """Uses the official template embedded in the imported Ollama model.

    Verify its template against the HF tokenizer before claiming parity.
    Ollama's server does not expose allocator peak memory; report null.
    """
    def __init__(self, model, endpoint="http://127.0.0.1:11434", seed=42):
        self.model, self.endpoint, self.seed = model, endpoint.rstrip("/"), seed

    def generate(self, messages, max_new_tokens=128):
        body = json.dumps({"model": self.model, "messages": messages, "stream": False,
            "think": False, "options": {"temperature": 0, "seed": self.seed, "num_predict": max_new_tokens}}).encode()
        request = urllib.request.Request(self.endpoint+"/api/chat", data=body,
                                         headers={"Content-Type": "application/json"})
        start = time.perf_counter()
        with urllib.request.urlopen(request, timeout=300) as response:
            result = json.load(response)
        return Generation(result["message"]["content"].strip(), result["eval_count"], time.perf_counter()-start)
