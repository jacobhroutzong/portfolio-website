"""TuneLedger: CPU-safe imports; GPU dependencies load only when requested."""
__version__ = "0.3.1"
