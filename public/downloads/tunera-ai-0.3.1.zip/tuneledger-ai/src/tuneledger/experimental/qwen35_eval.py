"""Measure one side of a paired evaluation for the experimental BF16 recipe."""
import argparse
import json
from pathlib import Path

from tuneledger.artifacts import digest
from tuneledger.datasets import load_splits
from tuneledger.evaluation import evaluate
from tuneledger.inference import TransformersAdapter
from .qwen35 import MODEL, REVISION, TARGET, verified_runtime


class Qwen35Adapter(TransformersAdapter):
    def __init__(self, torch, adapter, seed):
        from transformers import AutoTokenizer, Qwen3_5ForConditionalGeneration, set_seed

        set_seed(seed)
        self.torch = torch
        self.tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, trust_remote_code=False)
        self.model = Qwen3_5ForConditionalGeneration.from_pretrained(
            MODEL, revision=REVISION, dtype=torch.bfloat16, trust_remote_code=False, device_map={'': 0})
        if adapter:
            from peft import PeftModel

            self.model = PeftModel.from_pretrained(self.model, adapter)
        self.model.eval()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, type=Path)
    parser.add_argument('--data', required=True, type=Path)
    parser.add_argument('--label', required=True, choices=('base', 'fine_tuned'))
    parser.add_argument('--max-new-tokens', type=int, default=64, choices=range(1, 129), metavar='1..128')
    args = parser.parse_args()
    manifest = json.loads((args.run / 'manifest.json').read_text(encoding='utf-8'))
    config = manifest['config']
    if manifest['status'] != 'completed' or (config['target'], config['model_id'], config['revision']) != (TARGET, MODEL, REVISION):
        parser.error('Evaluation requires a completed pinned Qwen3.5 experiment')
    splits = load_splits(args.data)
    if digest(splits) != manifest['dataset_sha256']:
        parser.error('Use the same verified train/validation/test splits as the experiment')
    adapter = args.run / 'adapter' if args.label == 'fine_tuned' else None
    if adapter and not (adapter / 'adapter_config.json').is_file():
        parser.error('The fine-tuned run needs its saved adapter directory')
    output = args.run / 'evaluation'
    if (output / f'{args.label}.json').exists():
        parser.error('The selected evaluation report already exists')
    _, torch = verified_runtime()
    result = evaluate(Qwen35Adapter(torch, adapter, config['seed']), splits['test'], output, args.label,
                      args.max_new_tokens, provenance={'model_id': MODEL, 'revision': REVISION,
                      'quantized': False, 'seed': config['seed'], 'strategy': 'bf16-lora',
                      'smoke_only': manifest['smoke_only'], 'run_fingerprint': manifest['fingerprint']})
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
