import json
from pathlib import Path
import tempfile
import unittest
from tuneledger.datasets import read_jsonl
from tuneledger.evaluation import evaluate, score
from tuneledger.inference import Generation


class BenchmarkTests(unittest.TestCase):
    def test_json_metric_preserves_types_and_ignores_key_order(self):
        self.assertTrue(score('{"b": 2, "a": 1}', '{"a":1,"b":2}', scorer='json_exact')['accuracy'])
        self.assertFalse(score('{"a": true}', '{"a":1}', scorer='json_exact')['accuracy'])
        self.assertFalse(score('{"a":1,"a":2}', '{"a":2}', ['a'], 'json_exact')['structured_valid'])
        self.assertFalse(score('broken', '{"a":2}', scorer='json_exact')['accuracy'])
        with self.assertRaises(ValueError):
            score('{}', 'invalid reference', scorer='json_exact')

    def test_acceptance_suite_and_category_reports(self):
        rows = read_jsonl(Path(__file__).resolve().parents[1] / 'data/benchmarks/engineering_acceptance.jsonl')
        class Backend:
            def generate(self, messages, max_new_tokens=128):
                return Generation('{}', 1, 0.1)
        with tempfile.TemporaryDirectory() as tmp:
            report = evaluate(Backend(), rows, tmp, 'base')
            self.assertEqual(sum(v['count'] for v in report['categories'].values()), len(rows))
            self.assertEqual(report['accuracy'], 0)
            self.assertEqual(report['structured_validity'], 0)


if __name__ == '__main__':
    unittest.main()
