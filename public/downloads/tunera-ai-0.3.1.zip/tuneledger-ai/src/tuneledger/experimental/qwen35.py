"""Text-only BF16 LoRA experiment using the official Qwen3.5-2B checkpoint."""
import argparse
import json
import re
from dataclasses import replace
from functools import partial
from pathlib import Path
from types import SimpleNamespace

from tuneledger.artifacts import digest, environment, implementation_hash, write_json
from tuneledger.checkpoints import file_hash, latest_checkpoint, verify_checkpoint
from tuneledger.config import load_config
from tuneledger.datasets import load_splits
from tuneledger.tracking import event, trainer_callback
from tuneledger.training import LabelCollator, encode_rows, gpu_info

TARGET = 'qwen3.5-2b-bf16'
MODEL = 'Qwen/Qwen3.5-2B'
REVISION = '15852e8c16360a2fea060d615a32b45270f8a8fc'
RUNTIME = {'torch': '2.9.1+cu128', 'torchvision': '0.24.1+cu128',
           'transformers': '5.13.0', 'peft': '0.20.0', 'accelerate': '1.12.0'}
# The pinned checkpoint shard is 4,548,221,488 bytes. Reserve initial headroom
# above its weight storage before downloading it. This is a guard, not a fit guarantee.
MIN_FREE_GPU_BYTES = 4_548_221_488 + 768 * 2**20
# Scope PEFT to the language tower. Its projection names match the Unsloth text recipe.
PROJECTIONS = r'model\.language_model\..*\.(q_proj|k_proj|v_proj|o_proj|gate_proj|up_proj|down_proj)'


def encode_experiment_rows(rows, tokenizer, max_length):
    # Transformers 5 defaults to a dict. Keep the original Qwen3 loss-mask contract.
    legacy = SimpleNamespace(apply_chat_template=partial(tokenizer.apply_chat_template, return_dict=False))
    return encode_rows(rows, legacy, max_length, True)


def plan(config_path, data, smoke=False):
    config = load_config(config_path)
    if (config.target, config.model_id, config.revision) != (TARGET, MODEL, REVISION):
        raise ValueError('Use the pinned Qwen3.5-2B BF16 experiment configuration')
    if config.report_to != 'none' or not config.assistant_only_loss:
        raise ValueError('This experiment uses local tracking and final-assistant-only loss')
    if smoke:
        config = replace(config, max_steps=2, save_steps=1, eval_steps=1,
                         batch_size=1, gradient_accumulation_steps=1, max_length=min(config.max_length, 128))
    splits = load_splits(data)
    return config, splits


def verified_runtime():
    env = environment()
    for name, version in RUNTIME.items():
        if env['packages'].get(name) != version:
            raise RuntimeError(f'The isolated Qwen3.5 runtime requires {name} {version}')

    import torch
    if not torch.cuda.is_available() or not torch.cuda.is_bf16_supported(including_emulation=False):
        raise RuntimeError('Qwen3.5-2B requires a CUDA GPU with native BF16 support')
    free_bytes, _ = torch.cuda.mem_get_info()
    if free_bytes < MIN_FREE_GPU_BYTES:
        raise RuntimeError(f'Only {free_bytes / 2**30:.2f} GiB free on CUDA. This recipe requires '
                           f'at least {MIN_FREE_GPU_BYTES / 2**30:.2f} GiB free before weight loading.')
    return env, torch


def train(config, splits, output, smoke=False, resume=None):
    output = Path(output).resolve()
    checkpoint = None
    if resume == 'latest':
        checkpoint = latest_checkpoint(output)
    elif resume:
        if not re.fullmatch(r'checkpoint-\d+', resume):
            raise ValueError('Resume must name a checkpoint in this run')
        checkpoint = output / 'checkpoints' / resume
    if checkpoint:
        checkpoint = checkpoint.resolve()
        if not checkpoint.is_relative_to(output / 'checkpoints'):
            raise ValueError('Resume must reference a checkpoint within this run')
        verify_checkpoint(checkpoint)
    if output.exists() and any(output.iterdir()) and not checkpoint:
        raise ValueError('Use an empty output directory or resume this experiment')
    env, torch = verified_runtime()
    from peft import LoraConfig, get_peft_model
    from transformers import AutoTokenizer, Qwen3_5ForConditionalGeneration, Trainer, TrainingArguments, set_seed

    info = gpu_info()
    runtime = {'python': env['python'], 'packages': env['packages'], 'bf16': True}
    source = digest({'core': implementation_hash(), 'recipe': file_hash(__file__)})
    fingerprint = digest({'config': config.to_dict(), 'splits': splits, 'source': source})
    if checkpoint:
        previous = json.loads((output / 'manifest.json').read_text(encoding='utf-8'))
        if (previous['fingerprint'], previous['runtime'], previous['smoke_only']) != (fingerprint, runtime, smoke):
            raise ValueError('Resume requires the same resolved recipe, dataset, source, runtime and smoke setting')
    set_seed(config.seed)
    manifest = {'status': 'running', 'experimental': True, 'smoke_only': smoke,
                'config': config.to_dict(), 'dataset_sha256': digest(splits),
                'fingerprint': fingerprint, 'implementation_sha256': source, 'runtime': runtime,
                'environment': env, 'hardware': info, 'strategy': 'bf16-lora'}
    write_json(output / 'manifest.json', manifest)
    write_json(output / 'config.resolved.json', config.to_dict())
    event(output, 'resumed' if resume else 'started', fingerprint=fingerprint)
    torch.cuda.reset_peak_memory_stats()
    try:
        tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, trust_remote_code=False)
        if not tokenizer.chat_template:
            raise ValueError('Official tokenizer must supply a chat template')
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token = tokenizer.eos_token
        prepared = {name: encode_experiment_rows(splits[name], tokenizer, config.max_length)
                    for name in ('train', 'validation')}
        model = Qwen3_5ForConditionalGeneration.from_pretrained(
            MODEL, revision=REVISION, dtype=torch.bfloat16, trust_remote_code=False)
        model.config.text_config.use_cache = False
        model = get_peft_model(model, LoraConfig(
            task_type='CAUSAL_LM', r=config.rank, lora_alpha=config.lora_alpha,
            lora_dropout=0, bias='none', target_modules=PROJECTIONS))
        arguments = TrainingArguments(
            output_dir=str(output / 'checkpoints'), max_steps=config.max_steps,
            per_device_train_batch_size=config.batch_size, per_device_eval_batch_size=1,
            gradient_accumulation_steps=config.gradient_accumulation_steps,
            learning_rate=config.learning_rate, gradient_checkpointing=True,
            gradient_checkpointing_kwargs={'use_reentrant': False}, bf16=True,
            optim='adamw_torch', seed=config.seed, data_seed=config.seed,
            eval_strategy='steps', eval_steps=config.eval_steps, save_strategy='steps',
            save_steps=config.save_steps, save_total_limit=3, logging_steps=1,
            remove_unused_columns=False, prediction_loss_only=True, report_to='none', push_to_hub=False)
        trainer = Trainer(model=model, args=arguments, processing_class=tokenizer,
                          train_dataset=prepared['train'], eval_dataset=prepared['validation'],
                          data_collator=LabelCollator(tokenizer.pad_token_id), callbacks=[trainer_callback(output)])
        result = trainer.train(resume_from_checkpoint=str(checkpoint) if checkpoint else None)
        trainer.save_model(str(output / 'adapter'))
        write_json(output / 'training_metrics.json', result.metrics)
        manifest['status'] = 'completed'
    except BaseException as exc:
        manifest['status'] = ('oom' if isinstance(exc, torch.cuda.OutOfMemoryError)
                              else 'interrupted' if isinstance(exc, KeyboardInterrupt) else 'failed')
        manifest['error_type'] = type(exc).__name__
        raise
    finally:
        manifest['peak_gpu_allocated_bytes'] = torch.cuda.max_memory_allocated()
        manifest['peak_gpu_reserved_bytes'] = torch.cuda.max_memory_reserved()
        write_json(output / 'manifest.json', manifest)
        event(output, manifest['status'])
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    parser.add_argument('--data', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--resume', nargs='?', const='latest', help='Resume latest or a named sealed checkpoint from this experiment')
    parser.add_argument('--execute', action='store_true', help='Download the pinned model and train on local CUDA')
    args = parser.parse_args()
    config, splits = plan(args.config, args.data, args.smoke)
    result = train(config, splits, args.output, args.smoke, args.resume) if args.execute else {
        'status': 'plan-only', 'experimental': True, 'strategy': 'bf16-lora', 'config': config.to_dict(),
        'runtime_pins': RUNTIME, 'dataset_sha256': digest(splits), 'output': args.output,
        'resume': args.resume, 'smoke_only': args.smoke}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
