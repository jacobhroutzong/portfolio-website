import contextlib
import copy
import io
import json
import sys
import tempfile
import types
import unittest
from dataclasses import asdict, replace
from pathlib import Path
from unittest.mock import Mock, patch

from tuneledger.artifacts import write_json
from tuneledger.checkpoints import seal_checkpoint, verify_checkpoint, latest_checkpoint
from tuneledger.cli import main
from tuneledger.config import Config, load_config
from tuneledger.datasets import read_jsonl, save_splits, split_dataset
from tuneledger.deployment import stage_space
from tuneledger.hub import authenticated_api, sync_run, restore_run
from tuneledger.models import require_target
from tuneledger.pipeline import pipeline
from tuneledger.runners import JobSpec, HFJobsRunner, LocalRunner, local_plan
from tuneledger.tracking import event, list_runs

ROOT = Path(__file__).resolve().parents[1]


def checkpoint(path):
    path.mkdir(parents=True, exist_ok=True)
    for name in ('optimizer.pt', 'scheduler.pt', 'rng_state.pth', 'adapter_model.safetensors'):
        (path / name).write_bytes(b'CPU test double, not real model state')
    write_json(path / 'trainer_state.json', {'global_step': 1})
    return path


def spec(**updates):
    values = dict(image='example/training@sha256:' + 'a' * 64,
                  dataset_repo='jacobroutzong/test-data', dataset_revision='b' * 40,
                  artifact_repo='jacobroutzong/test-run', config=Config().to_dict(), run_name='trial')
    values.update(updates)
    return JobSpec(**values)


class CheckpointTests(unittest.TestCase):
    def test_integrity_and_latest_skips_partial_checkpoint(self):
        with tempfile.TemporaryDirectory() as tmp:
            first = seal_checkpoint(checkpoint(Path(tmp) / 'checkpoints/checkpoint-2'))
            second = checkpoint(Path(tmp) / 'checkpoints/checkpoint-3')
            self.assertEqual(latest_checkpoint(tmp), first)
            seal_checkpoint(second)
            self.assertEqual(latest_checkpoint(tmp), second)
            (second / 'optimizer.pt').write_bytes(b'corrupt')
            with self.assertRaisesRegex(ValueError, 'integrity'):
                verify_checkpoint(second)
            self.assertEqual(latest_checkpoint(tmp), first)

    def test_incomplete_and_untracked_files_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = checkpoint(Path(tmp) / 'checkpoint-1')
            (p / 'optimizer.pt').unlink()
            with self.assertRaises(ValueError):
                seal_checkpoint(p)
            checkpoint(p)
            seal_checkpoint(p)
            (p / 'unexpected.txt').write_text('incomplete write')
            with self.assertRaisesRegex(ValueError, 'file set'):
                verify_checkpoint(p)


class RunnerTests(unittest.TestCase):
    def test_colab_requires_attached_runtime_for_execution(self):
        from tuneledger.runners import ColabRunner
        with patch('importlib.util.find_spec', side_effect=ModuleNotFoundError), patch('subprocess.run') as run:
            with self.assertRaisesRegex(RuntimeError, 'inside Colab'):
                ColabRunner().submit({'command': ['unused']}, execute=True)
            run.assert_not_called()

    def test_job_management_checks_account_and_explicit_cancel(self):
        api = Mock()
        api.inspect_job.return_value = types.SimpleNamespace(id='job-1', url='https://example.invalid/job',
                       status=types.SimpleNamespace(stage='COMPLETED', message=None))
        api.fetch_job_logs.return_value = iter(['test log'])
        runner = HFJobsRunner()
        with patch('tuneledger.hub.authenticated_api', return_value=api):
            self.assertEqual(runner.manage('job-1')['stage'], 'COMPLETED')
            self.assertEqual(runner.manage('job-1', 'logs'), ['test log'])
            with self.assertRaises(ValueError):
                runner.manage('job-1', 'cancel')
            runner.manage('job-1', 'cancel', execute=True)
        api.cancel_job.assert_called_once_with(job_id='job-1', namespace='jacobroutzong')

    def test_offline_plan_and_cli_never_launch_gpu(self):
        with tempfile.TemporaryDirectory() as tmp:
            save_splits(split_dataset(read_jsonl(ROOT / 'data/smoke.jsonl')), tmp)
            plan = local_plan(ROOT / 'configs/qwen3_4b.json', tmp, Path(tmp) / 'run', True)
            with patch('subprocess.run') as run:
                self.assertEqual(LocalRunner().submit(plan), plan)
                self.assertEqual(sum(plan['counts'].values()), 40)
                with contextlib.redirect_stdout(io.StringIO()) as output:
                    main(['launch', '--provider', 'colab', '--config', str(ROOT / 'configs/qwen3_4b.json'),
                          '--data', tmp, '--output', str(Path(tmp) / 'run'), '--smoke'])
                self.assertEqual(json.loads(output.getvalue())['provider'], 'colab')
                run.assert_not_called()

    def test_remote_spec_rejects_mutable_or_invalid_inputs(self):
        for update in ({'image': 'training:latest'}, {'dataset_revision': 'main'},
                       {'resume_revision': 'main'}, {'timeout_seconds': True},
                       {'timeout_seconds': 86401}, {'run_name': '../escape'},
                       {'artifact_repo': 'other/run'}, {'smoke': 'false'},
                       {'config': replace(Config(), revision='main').to_dict()}):
            with self.subTest(update=update), self.assertRaises(ValueError):
                spec(**update)

    def test_billable_jobs_require_explicit_approval(self):
        runner = HFJobsRunner()
        with patch('tuneledger.hub.authenticated_api') as api:
            plan = runner.submit(spec())
            self.assertTrue(plan['billable'])
            self.assertNotIn('secrets', plan)
            with self.assertRaisesRegex(ValueError, 'cost approval'):
                runner.submit(spec(), execute=True)
            api.assert_not_called()

    def test_submission_uses_sdk_contract_and_only_secret_channel(self):
        api = Mock()
        api.repo_exists.return_value = False
        api.dataset_info.return_value = types.SimpleNamespace(siblings=[types.SimpleNamespace(rfilename=n)
              for n in ('train.jsonl', 'validation.jsonl', 'test.jsonl')])
        api.run_job.return_value = types.SimpleNamespace(id='test-id', url='https://example.invalid/job')
        with patch('tuneledger.hub.authenticated_api', return_value=api), \
             patch('huggingface_hub.get_token', return_value='test-secret'):
            result = HFJobsRunner().submit(spec(), execute=True, approve_cost=True)
        self.assertEqual(result['id'], 'test-id')
        kwargs = api.run_job.call_args.kwargs
        from huggingface_hub import HfApi
        import inspect
        inspect.signature(HfApi.run_job).bind(api, **kwargs)
        self.assertEqual(kwargs.pop('secrets'), {'HF_TOKEN': 'test-secret'})
        self.assertNotIn('test-secret', json.dumps(kwargs))
        self.assertEqual(kwargs['timeout'], 1800)

    def test_existing_public_or_occupied_artifact_repo_is_rejected(self):
        api = Mock()
        api.repo_exists.return_value = True
        with patch('tuneledger.hub.authenticated_api', return_value=api):
            api.repo_info.return_value.private = False
            with self.assertRaises(ValueError):
                HFJobsRunner().submit(spec(), True, True)
            api.repo_info.return_value.private = True
            api.file_exists.return_value = True
            with self.assertRaises(ValueError):
                HFJobsRunner().submit(spec(), True, True)
        api.run_job.assert_not_called()

    def test_pipeline_separates_gpu_processes_and_does_not_execute_by_default(self):
        with tempfile.TemporaryDirectory() as tmp:
            save_splits(split_dataset(read_jsonl(ROOT / 'data/smoke.jsonl')), tmp)
            with patch('subprocess.run') as run:
                plan = pipeline(ROOT / 'configs/qwen3_4b.json', tmp, Path(tmp) / 'run', smoke=True)
            run.assert_not_called()
            self.assertEqual(len(plan['commands']), 3)
            self.assertIn('train', plan['commands'][0])
            self.assertIn('base', plan['commands'][1])
            self.assertIn('fine_tuned', plan['commands'][2])
            self.assertNotIn('--adapter', plan['commands'][1])


class HubAndTrackingTests(unittest.TestCase):
    def test_restore_pins_snapshot_and_verifies_checkpoint(self):
        api = Mock()
        api.repo_info.return_value.private = True
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp) / 'restored'
            def download(*args, **kwargs):
                seal_checkpoint(checkpoint(Path(kwargs['local_dir']) / 'checkpoints/checkpoint-1'))
            with patch('tuneledger.hub.authenticated_api', return_value=api), \
                 patch('huggingface_hub.snapshot_download', side_effect=download) as snapshot:
                restored = restore_run('jacobroutzong/run', 'a' * 40, dest, enabled=True)
                self.assertEqual(restored.name, 'checkpoint-1')
                self.assertEqual(snapshot.call_args.kwargs['revision'], 'a' * 40)
                with self.assertRaises(ValueError):
                    restore_run('jacobroutzong/run', 'a' * 40, dest, enabled=True)

    def test_private_sync_uses_only_run_artifact_patterns(self):
        api = Mock()
        api.repo_info.return_value.private = True
        with patch('tuneledger.hub.authenticated_api', return_value=api):
            sync_run('test-run', 'jacobroutzong/run', enabled=True)
        self.assertTrue(api.create_repo.call_args.kwargs['private'])
        patterns = api.upload_folder.call_args.kwargs['allow_patterns']
        self.assertNotIn('*', patterns)
        self.assertNotIn('train.jsonl', patterns)
        self.assertIn('checkpoints/checkpoint-*/*', patterns)

    def test_wrong_owner_and_disabled_storage_never_write(self):
        with patch('huggingface_hub.HfApi') as cls:
            cls.return_value.whoami.return_value = {'name': 'someone-else'}
            with self.assertRaises(ValueError):
                authenticated_api('jacobroutzong/run')
            with self.assertRaises(ValueError):
                authenticated_api('someone-else/run')
            with self.assertRaises(ValueError):
                sync_run('missing', 'jacobroutzong/run')
            with self.assertRaises(ValueError):
                restore_run('jacobroutzong/run', 'a' * 40, 'missing')
            cls.return_value.create_repo.assert_not_called()

    def test_events_and_catalog(self):
        with tempfile.TemporaryDirectory() as tmp:
            run = Path(tmp) / 'trial'
            write_json(run / 'manifest.json', {'status': 'running', 'config': Config().to_dict()})
            event(run, 'started')
            event(run, 'metrics', step=1, metrics={'loss': 0.5})
            records = [json.loads(line) for line in (run / 'events.jsonl').read_text().splitlines()]
            self.assertEqual([r['event'] for r in records], ['started', 'metrics'])
            self.assertEqual(list_runs(tmp)[0]['target'], 'qwen3-4b')

    def test_space_staging_does_not_copy_unapproved_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            stage = stage_space(ROOT / 'space', Path(tmp) / 'space')
            self.assertEqual({p.name for p in stage.iterdir()},
                             {'app.py', 'demo_core.py', 'Dockerfile', 'tuneledger', 'LICENSE', 'README.md', 'requirements.txt', 'requirements.lock', 'benchmarks.json'})
            self.assertEqual(json.loads((stage / 'benchmarks.json').read_text())['results'], [])
            with self.assertRaises(ValueError):
                stage_space(ROOT / 'space', stage)

    def test_model_registry_and_strict_config(self):
        for size in ('0.6b', '1.7b', '4b', '8b'):
            require_target(replace(Config(), target=f'qwen3-{size}', model_id=f'Qwen/Qwen3-{size.upper()}'))
        for name in ('qwen3_0_6b.json', 'qwen3_1_7b.json', 'qwen3_4b.json', 'qwen3_8b.json'):
            config = load_config(ROOT / 'configs' / name)
            require_target(config)
            self.assertEqual(len(config.revision), 40)
        for value in (True, '0.001', float('inf'), float('nan')):
            with self.assertRaises(ValueError):
                Config(learning_rate=value)
        with tempfile.TemporaryDirectory() as tmp:
            write_json(Path(tmp) / 'config.json', [])
            with self.assertRaises(ValueError):
                load_config(Path(tmp) / 'config.json')


class TrainingLifecycleTests(unittest.TestCase):
    """Execute orchestration with explicit CPU doubles, never simulate benchmark evidence."""
    def modules(self, fail=None):
        class Tokenizer:
            pad_token_id = 0
            def apply_chat_template(self, messages, **kwargs):
                return [1, 2] if kwargs['add_generation_prompt'] else [1, 2, 3, 4]
            def save_pretrained(self, path):
                write_json(Path(path) / 'tokenizer_config.json', {'test_double': True})

        class Trainer:
            def __init__(self, **kwargs):
                self.args, self.callbacks = kwargs['args'], kwargs['callbacks']
            def train(self, resume_from_checkpoint=None):
                if fail == 'oom':
                    raise MemoryError('CPU double for CUDA OOM')
                state = types.SimpleNamespace(is_world_process_zero=True, global_step=1)
                cp = checkpoint(Path(self.args.output_dir) / 'checkpoint-1')
                for callback in self.callbacks:
                    callback.on_log(self.args, state, None, logs={'loss': 0.25})
                    callback.on_save(self.args, state, None)
                return types.SimpleNamespace(metrics={'train_loss': 0.25})
            def save_model(self, path):
                p = Path(path)
                p.mkdir(parents=True, exist_ok=True)
                (p / 'adapter_model.safetensors').write_bytes(b'CPU double')
                write_json(p / 'adapter_config.json', {})

        modules = {'unsloth': types.SimpleNamespace(FastLanguageModel=object),
            'torch': types.SimpleNamespace(backends=types.SimpleNamespace(cudnn=types.SimpleNamespace(benchmark=True)),
                                          cuda=types.SimpleNamespace(OutOfMemoryError=MemoryError, empty_cache=lambda: None)),
            'datasets': types.SimpleNamespace(Dataset=types.SimpleNamespace(from_list=lambda x: x)),
            'huggingface_hub': types.SimpleNamespace(model_info=lambda *a, **k: types.SimpleNamespace(sha=Config().revision)),
            'transformers': types.SimpleNamespace(TrainerCallback=object, set_seed=lambda x: None),
            'trl': types.SimpleNamespace(SFTTrainer=Trainer, SFTConfig=lambda **kw: types.SimpleNamespace(**kw))}
        return modules, Tokenizer()

    def execute(self, data, run, resume=None, fail=None, packages=None, sync=None):
        from tuneledger.training import train
        modules, tokenizer = self.modules(fail)
        with patch.dict(sys.modules, modules), \
             patch('tuneledger.training.gpu_info', return_value={'bf16': True}), \
             patch('tuneledger.training.environment', return_value={'python': '3.12', 'packages': packages or {}}), \
             patch('tuneledger.training.load_training_model', return_value=(object(), tokenizer)):
            return train(Config(), data, run, resume=resume, smoke=True, checkpoint_sync=sync)

    def test_training_resume_and_environment_rejection(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, run = Path(tmp) / 'data', Path(tmp) / 'run'
            save_splits(split_dataset(read_jsonl(ROOT / 'data/smoke.jsonl')), data)
            self.assertEqual(self.execute(data, run)['status'], 'completed')
            verify_checkpoint(run / 'checkpoints/checkpoint-1')
            self.assertEqual(self.execute(data, run, resume='latest')['status'], 'completed')
            with self.assertRaisesRegex(ValueError, 'Python/package'):
                self.execute(data, run, resume='latest', packages={'torch': 'different'})
            with self.assertRaisesRegex(ValueError, 'already exists'):
                self.execute(data, run)

    def test_oom_is_durable_and_does_not_claim_completion(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, run = Path(tmp) / 'data', Path(tmp) / 'run'
            save_splits(split_dataset(read_jsonl(ROOT / 'data/smoke.jsonl')), data)
            with self.assertRaisesRegex(RuntimeError, 'GPU OOM'):
                self.execute(data, run, fail='oom')
            self.assertEqual(json.loads((run / 'manifest.json').read_text())['status'], 'oom')

    def test_storage_failure_keeps_verified_checkpoint_for_recovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, run = Path(tmp) / 'data', Path(tmp) / 'run'
            save_splits(split_dataset(read_jsonl(ROOT / 'data/smoke.jsonl')), data)
            with self.assertRaisesRegex(OSError, 'storage offline'):
                self.execute(data, run, sync=Mock(side_effect=OSError('storage offline')))
            self.assertEqual(json.loads((run / 'manifest.json').read_text())['status'], 'failed')
            verify_checkpoint(run / 'checkpoints/checkpoint-1')
            self.assertEqual(self.execute(data, run, resume='latest')['status'], 'completed')


class WorkerTests(unittest.TestCase):
    def test_worker_saves_state_when_pipeline_fails(self):
        from tuneledger.worker import main as worker
        with tempfile.TemporaryDirectory() as tmp:
            def download(*args, **kwargs):
                save_splits(split_dataset(read_jsonl(ROOT / 'data/smoke.jsonl')), kwargs['local_dir'])
            with patch.dict('os.environ', {'TUNELEDGER_JOB': json.dumps(asdict(spec())), 'TUNELEDGER_WORKDIR': tmp}), \
                 patch('huggingface_hub.snapshot_download', side_effect=download), \
                 patch('tuneledger.worker.sync_run') as sync, \
                 patch('tuneledger.pipeline.pipeline', side_effect=RuntimeError('CPU test failure')) as execute:
                with self.assertRaisesRegex(RuntimeError, 'CPU test failure'):
                    worker()
                self.assertEqual(sync.call_count, 2)
                self.assertTrue(execute.call_args.kwargs['execute'])
                self.assertEqual(execute.call_args.kwargs['checkpoint_repo'], spec().artifact_repo)


if __name__ == '__main__':
    unittest.main()
