# Compute policy derived from the user's request

This file records the policy supplied in chat. It is not the missing attached
`COMPUTE_POLICY.md` or an assertion that its contents were read.

1. Prefer an existing Google Colab Pro allocation through Google's official
   Colab MCP integration when exposed by the client. No unofficial runtime APIs.
2. Use HF Jobs as the automated GPU alternative, with containerized, bounded jobs.
3. Use private Hub storage for experiment recovery and checkpoints. Stage public
   releases locally for review. Keep tokens in CLI/provider secret stores.
4. Run CPU tests, tokenizer checks and offline plans autonomously.
5. Do not initiate additional billable charges or publicly publish artifacts
   without the user's approval. The user subsequently approved portfolio
   publication and explicitly approved a public CPU Space. GPU spending remains
   unapproved; the demo uses cpu-basic hardware and starts no training.

`launch` defaults to planning. HF Jobs execution requires both `--execute` and
`--approve-cost`; supplying those flags is an operator assertion of prior human
approval, not a replacement for it. Every executing remote job writes private
checkpoints to the declared artifact repository. Model release upload is a
separate `publish --upload` operation, private by default; `--public` is explicit.
Space and portfolio publication require separate approval. The code never
requests paid Space hardware or automatically upgrades compute.

The local GPU is a Windows RTX 4070 Laptop GPU with 8 GB VRAM. The supplied
Unsloth training extra targets Linux. No local Qwen model weights were downloaded
and no training was attempted. The official tokenizer download used no GPU.

For Colab, pair the official browser bridge from the signed-in browser profile.
Check the included compute balance and the runtime's usage rate before training.
Use MCP cells to fetch a commit-pinned source ZIP and verify its SHA-256, install
the frozen environment, run training and recovery, and collect the reports.
That workflow uses a scratch Colab tab and does not require a notebook upload
or manual file transfer. Export small reports through MCP before releasing the
runtime. For checkpoints that must survive eviction, write to a separately
authorized private artifact store. Drive and Secrets may require account consent.
The example MCP configuration is included for reference. Colab availability
varies, and additional compute purchases require approval.
