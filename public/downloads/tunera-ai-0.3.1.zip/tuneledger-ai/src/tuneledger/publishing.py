"""Explicit, private-by-default adapter publication; allowlist upload only."""
import os
from pathlib import Path
from .artifacts import write_json


def stage_release(run_dir, release_dir, metadata):
    import json
    import shutil
    run, release = Path(run_dir), Path(release_dir)
    manifest = json.loads((run/"manifest.json").read_text())
    if manifest["status"] != "completed" or manifest["smoke_only"]:
        raise ValueError("Only completed, non-smoke training runs may be published")
    if release.exists():
        raise ValueError("Use a new empty release directory")
    adapter = run/"adapter"
    if not (adapter/"adapter_config.json").is_file() or not (adapter/"adapter_model.safetensors").is_file():
        raise ValueError("Missing adapter weights or configuration")
    required = {"dataset_name", "license", "source", "train_count", "validation_count", "test_count"}
    if set(metadata) != required:
        raise ValueError(f"Public metadata must contain exactly {sorted(required)}")
    if any(type(metadata[k]) is not int or metadata[k] < 0 for k in ("train_count", "validation_count", "test_count")):
        raise ValueError("Dataset counts must be nonnegative integers")
    release.mkdir(parents=True)
    allowed = ("adapter_config.json", "adapter_model.safetensors", "tokenizer.json",
               "tokenizer_config.json", "special_tokens_map.json", "chat_template.jinja", "vocab.json", "merges.txt")
    for name in allowed:
        if (adapter/name).is_file():
            shutil.copy2(adapter/name, release/name)
    # Caller supplies public, aggregate dataset metadata; do not upload raw runs/data.
    write_json(release/"dataset_metadata.json", metadata)
    write_json(release/"experiment.json", {"config": manifest["config"], "dataset_sha256": manifest["dataset_sha256"]})
    (release/"README.md").write_text(
        f"---\nbase_model: {manifest['config']['model_id']}\nlibrary_name: peft\ntags: [tuneledger, lora]\n---\n"
        "# TuneLedger adapter\n\nQLoRA adapter; load with the base revision in experiment.json.\n\n"
        "Training settings and aggregate dataset provenance are included. No quality improvements are claimed. "
        "Evaluate on a licensed, isolated task suite before use. This release does not establish safety or suitability "
        "for high-stakes use. Base model terms and dataset terms apply.\n", encoding="utf-8")
    return release


def upload(release_dir, repo_id, enabled=False, private=True):
    if not enabled:
        raise ValueError("Uploads require explicit --upload")
    token = os.environ.get("HF_TOKEN")
    if not token:
        raise ValueError("HF_TOKEN environment secret required")
    from huggingface_hub import HfApi
    api = HfApi(token=token)
    if repo_id.split('/')[0] != 'jacobroutzong' or api.whoami()['name'] != 'jacobroutzong':
        raise ValueError('Publishing requires the intended jacobroutzong account and namespace')
    # Verify staging structure and reject any unexpected file before network mutation.
    allowed = {"adapter_config.json", "adapter_model.safetensors", "tokenizer.json", "tokenizer_config.json",
               "special_tokens_map.json", "chat_template.jinja", "vocab.json", "merges.txt",
               "README.md", "dataset_metadata.json", "experiment.json"}
    files = list(Path(release_dir).iterdir())
    required = {"adapter_config.json", "adapter_model.safetensors", "README.md", "dataset_metadata.json", "experiment.json"}
    if not required.issubset({p.name for p in files}) or any(p.name not in allowed or not p.is_file() or p.is_symlink() for p in files):
        raise ValueError("Unexpected release content; refusing upload")
    api.create_repo(repo_id, repo_type="model", private=private, exist_ok=True)
    info = api.repo_info(repo_id, repo_type="model")
    if private and not info.private:
        raise ValueError("Existing repository is public; explicit --public required")
    return api.upload_folder(repo_id=repo_id, folder_path=release_dir, repo_type="model")
