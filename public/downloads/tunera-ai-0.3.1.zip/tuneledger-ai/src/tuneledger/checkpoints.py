"""Checksummed completion records for recoverable Trainer checkpoints."""
import hashlib
import json
from pathlib import Path
from .artifacts import write_json


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def seal_checkpoint(directory):
    path = Path(directory)
    names = {p.name for p in path.iterdir() if p.is_file()}
    required = {'trainer_state.json', 'optimizer.pt', 'scheduler.pt'}
    if not required <= names or not any(n.startswith('rng_state') for n in names):
        raise ValueError('Checkpoint lacks optimizer, scheduler, Trainer or RNG state')
    if not names & {'adapter_model.safetensors', 'model.safetensors', 'pytorch_model.bin'}:
        raise ValueError('Checkpoint lacks model/adapter weights')
    files = {}
    for p in sorted(path.rglob('*')):
        if p.is_symlink():
            raise ValueError('Checkpoint symlinks are unsupported')
        if p.is_file() and p.name != 'complete.json':
            files[p.relative_to(path).as_posix()] = file_hash(p)
    write_json(path / 'complete.json', {'files': files})
    return path


def verify_checkpoint(directory):
    path = Path(directory).resolve()
    record = json.loads((path / 'complete.json').read_text(encoding='utf-8'))
    files = record['files']
    required = {'trainer_state.json', 'optimizer.pt', 'scheduler.pt'}
    if not required <= files.keys() or not any(n.startswith('rng_state') for n in files):
        raise ValueError('Incomplete checkpoint record')
    if not files.keys() & {'adapter_model.safetensors', 'model.safetensors', 'pytorch_model.bin'}:
        raise ValueError('Checkpoint record lacks weights')
    actual = {p.relative_to(path).as_posix() for p in path.rglob('*') if p.is_file() and p.name != 'complete.json'}
    if actual != set(files):
        raise ValueError('Checkpoint file set changed')
    for name, expected in files.items():
        p = (path / name).resolve()
        if not p.is_relative_to(path) or p.is_symlink() or file_hash(p) != expected:
            raise ValueError('Checkpoint integrity verification failed')
    return path


def latest_checkpoint(run):
    candidates = []
    for p in (Path(run) / 'checkpoints').glob('checkpoint-*'):
        try:
            step = int(p.name.split('-')[-1])
            verify_checkpoint(p)
            candidates.append((step, p))
        except (ValueError, OSError, KeyError, TypeError):
            continue
    if not candidates:
        raise ValueError('No verified complete checkpoint exists')
    return max(candidates)[1]
