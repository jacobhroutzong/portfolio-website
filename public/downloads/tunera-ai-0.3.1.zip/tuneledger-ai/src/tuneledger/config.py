"""Strict JSON experiment configuration; no arbitrary Python/YAML execution."""
import json
import math
from dataclasses import asdict, dataclass, fields
from pathlib import Path


@dataclass(frozen=True)
class Config:
    target: str = "qwen3-4b"
    model_id: str = "Qwen/Qwen3-4B"
    revision: str = "1cfa9a7208912126459214e8b04321603b3df60c"
    seed: int = 42
    max_length: int = 512
    rank: int = 16
    lora_alpha: int = 32
    learning_rate: float = 0.0002
    batch_size: int = 1
    gradient_accumulation_steps: int = 4
    max_steps: int = 100
    save_steps: int = 20
    eval_steps: int = 20
    assistant_only_loss: bool = True
    report_to: str = "none"

    def __post_init__(self):
        for key in ("seed", "max_length", "rank", "lora_alpha", "batch_size",
                    "gradient_accumulation_steps", "max_steps", "save_steps", "eval_steps"):
            value = getattr(self, key)
            if type(value) is not int or value < (0 if key == "seed" else 1):
                raise ValueError(f"{key} must be a positive integer (seed may be zero)")
        if type(self.learning_rate) not in (int, float) or not math.isfinite(self.learning_rate) or not 0 < self.learning_rate < 1:
            raise ValueError("learning_rate must be between zero and one")
        if type(self.assistant_only_loss) is not bool or self.report_to not in ("none", "wandb"):
            raise ValueError("Invalid loss or tracking setting")
        if not isinstance(self.revision, str) or not self.revision:
            raise ValueError("A model revision is required")
        if not all(isinstance(v, str) and v.strip() for v in (self.target, self.model_id)):
            raise ValueError('Target and model_id must be nonempty strings')

    def to_dict(self):
        return asdict(self)


def load_config(path):
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError('Configuration must be a JSON object')
    unknown = raw.keys() - {f.name for f in fields(Config)}
    if unknown:
        raise ValueError(f"Unknown configuration keys: {sorted(unknown)}")
    return Config(**raw)
