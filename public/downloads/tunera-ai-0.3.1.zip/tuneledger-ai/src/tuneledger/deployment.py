"""Stage a CPU Space with aggregate measured results; no network mutation."""
import json
import shutil
from pathlib import Path
from .artifacts import write_json


def stage_space(template, destination, comparison=None):
    template, destination = Path(template), Path(destination)
    if destination.exists():
        raise ValueError('Use a fresh Space staging directory')
    required = ('app.py', 'demo_core.py', 'brand.svg', 'Dockerfile', 'README.md', 'requirements.txt', 'requirements.lock')
    for name in required:
        if not (template / name).is_file() or (template / name).is_symlink():
            raise ValueError('Missing or unsafe Space template')
    destination.mkdir(parents=True)
    for name in required:
        shutil.copy2(template / name, destination / name)
    shutil.copytree(template / 'logos', destination / 'logos')
    license_file = template.parent / 'LICENSE'
    if license_file.is_file():
        shutil.copy2(license_file, destination / 'LICENSE')
    core = destination / 'tuneledger'
    core.mkdir()
    for name in ('__init__', 'artifacts', 'config', 'datasets', 'evaluation', 'inference'):
        shutil.copy2(Path(__file__).parent / f'{name}.py', core / f'{name}.py')
    public = {'status': 'No GPU benchmark results have been supplied', 'results': []}
    if comparison:
        result = json.loads(Path(comparison).read_text(encoding='utf-8'))
        keys = ('count', 'accuracy', 'structured_validity', 'mean_latency_seconds',
                'tokens_per_second', 'peak_gpu_bytes', 'suite_sha256')
        public = {'status': 'User-supplied evaluation; inspect dataset and hardware context',
                  'results': [{'label': label, **{k: result[label][k] for k in keys}}
                              for label in ('base', 'fine_tuned')]}
    write_json(destination / 'benchmarks.json', public)
    return destination
