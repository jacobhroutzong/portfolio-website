"""Bounded CPU-only public tools; no training, file writes or model downloads."""
import json
from dataclasses import replace
from tuneledger.artifacts import digest
from tuneledger.config import Config
from tuneledger.datasets import validate, split_dataset
from tuneledger.evaluation import score, strict_json

REVISIONS = {
    '0.6B': 'c1899de289a04d12100db370d81485cdf75e47ca',
    '1.7B': '70d244cc86ccca08cf5af4e1e306ecf908b1ad5e',
    '4B': '1cfa9a7208912126459214e8b04321603b3df60c',
    '8B': 'b968826d9c46dd6066d109eabc6255188de91218',
}
EXAMPLES = '\n'.join(json.dumps({'id': f'case-{i:02}', 'messages': [
    {'role': 'user', 'content': f'Return only JSON with key result: {i} + 2'},
    {'role': 'assistant', 'content': json.dumps({'result': i + 2})}],
    'required_keys': ['result'], 'scorer': 'json_exact'}) for i in range(1, 13))


def parse_rows(text):
    if not isinstance(text, str) or len(text.encode('utf-8')) > 256_000:
        raise ValueError('Dataset input is limited to 256 KB')
    lines = [line for line in text.splitlines() if line.strip()]
    if not 1 <= len(lines) <= 250:
        raise ValueError('Provide 1–250 JSONL cases')
    return validate([strict_json(line) for line in lines])


def validate_data(text):
    try:
        rows = parse_rows(text)
        result = {'valid': True, 'rows': len(rows), 'dataset_sha256': digest(rows),
                  'checks': ['conversation roles', 'unique IDs', 'normalized prompt duplicates', 'reserved delimiters'],
                  'semantic_deduplication': 'Not performed; label source_id for related documents'}
        try:
            splits = split_dataset(rows)
            result['split_preview'] = {k: {'count': len(v), 'sha256': digest(v)} for k, v in splits.items()}
        except ValueError as exc:
            result['split_preview'] = str(exc)
        return result
    except (ValueError, TypeError, KeyError) as exc:
        return {'valid': False, 'error': str(exc)}


def plan_run(size, context, rank, steps):
    if size not in REVISIONS:
        raise ValueError('Choose a registered Qwen3 model')
    config = replace(Config(), model_id=f'Qwen/Qwen3-{size}', target=f'qwen3-{size.lower()}',
                     revision=REVISIONS[size], max_length=int(context), rank=int(rank), max_steps=int(steps))
    return {'config': config.to_dict(), 'effective_batch_size': config.batch_size * config.gradient_accumulation_steps,
            'preferred_runner': 'Colab Pro with official MCP when connected',
            'alternative_runner': 'HF Jobs with pinned container and explicit cost approval',
            'recovery': 'Full Trainer state with SHA-256 completion record; resume only with identical data/config/source/runtime',
            'status': 'Configuration only. No compute started; GPU acceptance pending.'}


def score_outputs(text, outputs):
    try:
        rows = parse_rows(text)
        if not isinstance(outputs, str) or len(outputs.encode('utf-8')) > 256_000:
            raise ValueError('Saved outputs are limited to 256 KB')
        predictions = strict_json(outputs)
        if not isinstance(predictions, dict) or set(predictions) != {r['id'] for r in rows}:
            raise ValueError('Outputs must be a JSON object with exactly one string prediction per case ID')
        if not all(isinstance(v, str) for v in predictions.values()):
            raise ValueError('Each prediction must be text')
        results = [{'id': row['id'], **score(predictions[row['id']], row['messages'][-1]['content'],
                    row.get('required_keys'), row.get('scorer', 'exact_match'))} for row in rows]
        return {'source': 'Visitor-supplied saved outputs; no model was run', 'suite_sha256': digest(rows),
                'count': len(rows), 'accuracy': sum(r['accuracy'] for r in results) / len(results),
                'results': results}
    except (ValueError, TypeError, KeyError) as exc:
        return {'error': str(exc)}
