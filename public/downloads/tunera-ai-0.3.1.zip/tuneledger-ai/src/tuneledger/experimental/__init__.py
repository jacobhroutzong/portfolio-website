"""Opt-in recipes with isolated dependency environments."""
