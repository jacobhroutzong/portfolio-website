import os
import re
import tempfile
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

from tuneledger.checkpoints import verify_checkpoint
from tuneledger.config import Config, load_config
from tuneledger.datasets import read_jsonl, save_splits, split_dataset
from tuneledger.experimental.qwen35 import MODEL, PROJECTIONS, REVISION, TARGET, encode_experiment_rows, plan, train
from tuneledger.models import require_target

ROOT = Path(__file__).resolve().parents[1]
RECIPE = ROOT / 'configs/qwen3_5_2b.experimental.json'


class Qwen35ExperimentTests(unittest.TestCase):
    def test_pinned_smoke_plan_keeps_the_production_default(self):
        rows = read_jsonl(ROOT / 'data/smoke.jsonl')
        with tempfile.TemporaryDirectory() as data:
            save_splits(split_dataset(rows), data)
            config, splits = plan(RECIPE, data, smoke=True)
            self.assertEqual((config.target, config.model_id, config.revision), (TARGET, MODEL, REVISION))
            self.assertEqual((config.max_steps, config.save_steps, config.max_length), (2, 1, 128))
            self.assertEqual(sum(map(len, splits.values())), len(rows))
            altered = Path(data) / 'mutable.json'
            altered.write_text('{"target":"qwen3.5-2b-bf16","model_id":"Qwen/Qwen3.5-2B","revision":"main"}')
            with self.assertRaisesRegex(ValueError, 'pinned'):
                plan(altered, data)
        self.assertEqual(Config(), load_config(ROOT / 'configs/qwen3_4b.json'))
        require_target(Config())
        with self.assertRaises(NotImplementedError):
            require_target(config)

    def test_projection_selection_excludes_vision(self):
        self.assertIsNotNone(re.fullmatch(PROJECTIONS, 'model.language_model.layers.3.self_attn.q_proj'))
        self.assertIsNotNone(re.fullmatch(PROJECTIONS, 'model.language_model.layers.0.mlp.up_proj'))
        self.assertIsNone(re.fullmatch(PROJECTIONS, 'model.visual.blocks.0.attn.q_proj'))

    @unittest.skipUnless(os.environ.get('TUNERA_QWEN35_RUNTIME_TEST'), 'requires isolated PyTorch/PEFT runtime')
    def test_tiny_random_weight_recovery(self):
        import torch
        from transformers import AutoTokenizer, Qwen3_5Config, Qwen3_5ForConditionalGeneration, TrainingArguments
        from tuneledger.artifacts import environment

        directory = os.environ['TUNERA_QWEN35_TOKENIZER_DIR']
        tokenizer = AutoTokenizer.from_pretrained(directory, local_files_only=True)
        model_config = Qwen3_5Config(
            text_config={'vocab_size': len(tokenizer), 'hidden_size': 32, 'intermediate_size': 48,
                         'num_hidden_layers': 2, 'num_attention_heads': 4, 'num_key_value_heads': 2,
                         'head_dim': 8, 'linear_key_head_dim': 8, 'linear_value_head_dim': 8,
                         'linear_num_key_heads': 2, 'linear_num_value_heads': 4,
                         'layer_types': ['linear_attention', 'full_attention'], 'use_cache': False,
                         'pad_token_id': tokenizer.pad_token_id, 'eos_token_id': tokenizer.eos_token_id},
            vision_config={'depth': 1, 'hidden_size': 16, 'intermediate_size': 24,
                           'num_heads': 2, 'out_hidden_size': 32, 'num_position_embeddings': 16},
        )

        def tiny_model(*args, **kwargs):
            model = Qwen3_5ForConditionalGeneration(model_config)
            return model if cpu_only else model.to(dtype=kwargs['dtype'])

        cpu_only = os.environ['TUNERA_QWEN35_RUNTIME_TEST'] == 'cpu'

        rows = read_jsonl(ROOT / 'data/smoke.jsonl')
        with tempfile.TemporaryDirectory() as directory:
            data, run = Path(directory) / 'data', Path(directory) / 'run'
            save_splits(split_dataset(rows), data)
            config, splits = plan(RECIPE, data, smoke=True)
            with ExitStack() as patches:
                patches.enter_context(patch('tuneledger.experimental.qwen35.MIN_FREE_GPU_BYTES', 256 * 2**20))
                patches.enter_context(patch.object(AutoTokenizer, 'from_pretrained', return_value=tokenizer))
                patches.enter_context(patch.object(Qwen3_5ForConditionalGeneration, 'from_pretrained', side_effect=tiny_model))
                if cpu_only:
                    def cpu_args(**kwargs):
                        return TrainingArguments(**{**kwargs, 'bf16': False, 'use_cpu': True})

                    patches.enter_context(patch('tuneledger.experimental.qwen35.verified_runtime', return_value=(environment(), torch)))
                    patches.enter_context(patch('tuneledger.experimental.qwen35.gpu_info', return_value={'device': 'CPU contract test'}))
                    patches.enter_context(patch('transformers.TrainingArguments', side_effect=cpu_args))
                    for method in ('reset_peak_memory_stats', 'max_memory_allocated', 'max_memory_reserved'):
                        patches.enter_context(patch.object(torch.cuda, method, return_value=0))
                result = train(config, splits, run, smoke=True)
                self.assertEqual(result['status'], 'completed')
                if not cpu_only:
                    self.assertGreater(result['peak_gpu_allocated_bytes'], 0)
                    torch.cuda.empty_cache()
                verify_checkpoint(run / 'checkpoints/checkpoint-1')
                self.assertEqual(train(config, splits, run, smoke=True, resume='checkpoint-1')['status'], 'completed')
                verify_checkpoint(run / 'checkpoints/checkpoint-2')
                if cpu_only:
                    from tuneledger.evaluation import compare, evaluate
                    from tuneledger.experimental.qwen35_eval import Qwen35Adapter

                    evaluation = run / 'evaluation'
                    provenance = {'model_id': MODEL, 'revision': REVISION, 'quantized': False, 'seed': config.seed}
                    for label, adapter in [('base', None), ('fine_tuned', run / 'adapter')]:
                        backend = Qwen35Adapter(torch, adapter, config.seed)
                        result = evaluate(backend, splits['test'], evaluation, label, max_new_tokens=2, provenance=provenance)
                        self.assertEqual(result['count'], len(splits['test']))
                        self.assertIsNone(result['peak_gpu_bytes'])
                    paired = compare(evaluation / 'base.json', evaluation / 'fine_tuned.json', evaluation)
                    self.assertEqual(paired['base']['suite_sha256'], paired['fine_tuned']['suite_sha256'])

    @unittest.skipUnless(os.environ.get('TUNERA_QWEN35_TOKENIZER_DIR'), 'requires pinned local Qwen3.5 tokenizer files')
    def test_official_template_masks_final_reply(self):
        from transformers import AutoTokenizer

        tokenizer = AutoTokenizer.from_pretrained(os.environ['TUNERA_QWEN35_TOKENIZER_DIR'], local_files_only=True)
        rows = read_jsonl(ROOT / 'data/smoke.jsonl')
        for row, encoded in zip(rows, encode_experiment_rows(rows, tokenizer, 128)):
            trained = [token for token in encoded['labels'] if token != -100]
            self.assertEqual(tokenizer.decode(trained, skip_special_tokens=True).strip(), row['messages'][-1]['content'])
