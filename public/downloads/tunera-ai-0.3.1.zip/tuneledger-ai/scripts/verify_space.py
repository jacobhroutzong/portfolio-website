"""Local-only Space startup, Gradio, and portfolio API acceptance check."""
import os
from pathlib import Path
import runpy
import sys

from fastapi.testclient import TestClient


def main():
    os.environ['GRADIO_ANALYTICS_ENABLED'] = 'False'
    for key in ('TUNELEDGER_ENDPOINT', 'TUNELEDGER_OLLAMA_MODEL', 'TUNELEDGER_ENDPOINT_TOKEN'):
        os.environ.pop(key, None)
    source = Path(__file__).resolve().parents[1] / 'space'
    sys.path.insert(0, str(source))
    app = runpy.run_path(str(source / 'app.py'))
    assert 'unavailable' in app['respond']('hello', [])
    with TestClient(app['app']) as client:
        config = client.get('/config').json()
        assert config['title'] == 'Tunera'
        assert any(c['type'] == 'json' for c in config['components'])
        endpoint = '/api/tunera/v1'
        options = {'action': 'plan', 'size': '1.7B', 'context': 768, 'rank': 8, 'steps': 25}
        plan = client.post(endpoint, json=options)
        assert plan.status_code == 200
        assert plan.json() == app['plan_run']('1.7B', 768, 8, 25)
        assert plan.headers['cache-control'] == 'no-store'
        assert client.post(endpoint, json={**options, 'rank': 7}).status_code == 422
        cases = app['EXAMPLES']
        result = client.post(endpoint, json={'action': 'validate', 'cases': cases})
        assert result.status_code == 200 and result.json() == app['validate_data'](cases)
        assert result.json()['split_preview']['train']['count'] == 10
        assert client.post(endpoint, json={'action': 'validate', 'cases': 'bad'}).status_code == 422
        predictions = '{' + ','.join(f'"case-{i:02}":"{i+2}"' for i in range(1, 13)) + '}'
        score = client.post(endpoint, json={'action': 'score', 'cases': cases, 'predictions': predictions})
        assert score.status_code == 200 and score.json() == app['score_outputs'](cases, predictions)
        assert score.json()['count'] == 12 and score.json()['accuracy'] == 0
        assert client.post(endpoint, json={'action': 'train'}).status_code == 422
        assert client.post(endpoint, content=b'plain text').status_code == 415
        oversized = b' ' * (app['MAX_REQUEST_BYTES'] + 1)
        assert client.post(endpoint, content=oversized, headers={'Content-Type': 'application/json'}).status_code == 413
    print('PASS: mounted Space UI, offline inference, portfolio tools, and input limits')


if __name__ == '__main__':
    main()
