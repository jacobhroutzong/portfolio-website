"""Training and paired evaluation in isolated processes to release GPU memory."""
import subprocess
import sys
from pathlib import Path
from .artifacts import write_json
from .runners import local_plan


def pipeline(config, data, output, smoke=False, resume=None, execute=False, checkpoint_repo=None):
    plan = local_plan(config, data, output, smoke, resume)
    run = Path(output)
    training = plan['command']
    if checkpoint_repo:
        training += ['--checkpoint-repo', checkpoint_repo, '--approve-hub-write']
    commands = [training]
    for label in ('base', 'fine_tuned'):
        command = [sys.executable, '-m', 'tuneledger.cli', 'evaluate', '--config',
                   str(run / 'config.resolved.json'), '--test', str(Path(data) / 'test.jsonl'),
                   '--output', str(run / 'evaluation'), '--label', label, '--quantized']
        if label == 'fine_tuned':
            command += ['--adapter', str(run / 'adapter')]
        commands.append(command)
    result = {'commands': commands, 'executed': execute, 'smoke_only': smoke}
    if not execute:
        return result
    try:
        for command in commands:
            subprocess.run(command, check=True)
        from .evaluation import compare
        comparison = compare(run / 'evaluation/base.json', run / 'evaluation/fine_tuned.json', run / 'evaluation')
        result['regression_pass'] = comparison['regression_pass']
        result['status'] = 'completed' if smoke or comparison['regression_pass'] else 'regression'
    except BaseException as exc:
        result['status'] = 'failed'
        result['error_type'] = type(exc).__name__
        raise
    finally:
        write_json(run / 'pipeline.json', result)
    return result
