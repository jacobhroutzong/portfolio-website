# CUDA compatibility — candidate matrix, not measured certification

The lock resolves a compatible dependency graph. Only CPU packaging/tests were
executed here. The following are execution targets, not validated GPU results.

| Target | OS / Python | Precision | Status |
|---|---|---|---|
| CPU unit tests | Windows / 3.12 | none | executed locally |
| CPU CI | Ubuntu + Windows / 3.11–3.13 | none | configured; remote run pending |
| Colab T4 (SM75) | Linux / 3.12 | 4-bit weights + FP16 compute | smoke required; context may need reduction |
| Colab L4 (SM89) | Linux / 3.12 | 4-bit + BF16 | smoke required |
| Colab A100 (SM80) | Linux / 3.12 | 4-bit + BF16 | smoke required |
| RTX 4070 Laptop (SM89) | Windows/WSL2 / 3.12 | 4-bit inference | available VRAM dependent; untested |
| Qwen3.5 BF16 LoRA | unspecified | BF16 | scaffold, execution blocked |
| gpt-oss-20b | unspecified | unspecified | scaffold, execution blocked |

Resolved training stack: torch **2.9.1**, Triton **3.5.1**, xformers
**0.0.33.post2**, Transformers **4.57.6**, PEFT **0.18.1**, TRL **0.24.0**,
Unsloth **2026.10.3**, unsloth-zoo **2026.10.6**, bitsandbytes **0.49.2**.
Always inspect `uv.lock` as the authority if regenerating dependencies.

The Linux PyPI torch wheel resolves CUDA **12.8.90** runtime dependencies in this lock.
The installed NVIDIA driver must support that runtime; a local CUDA toolkit
version alone does not establish compatibility. The preflight records
`torch.version.cuda`, torch version, compute capability, VRAM and BF16 support;
verify `nvidia-smi` on the target runtime before model loading. Package import,
kernel compilation and a two-step optimizer run remain required compatibility
checks. The runtime's preinstalled torch is not used by the isolated uv env.

Unsloth GPU training is constrained to Linux in this repository's extra. Native
Windows Unsloth training has not been validated; use Colab or a separately
validated WSL2 environment. Windows CPU/inference dependencies are resolvable.
macOS is outside this lock's supported environments.

Do not mix an arbitrary torch CUDA wheel with this xformers/Triton combination.
For a different CUDA stack, create a separate reviewed lock and record actual
successful hardware/version results. If CUDA fails, stop before long training.
Sources: [Unsloth requirements](https://unsloth.ai/docs/get-started/fine-tuning-for-beginners/unsloth-requirements)
and [PyTorch installation](https://pytorch.org/get-started/locally/).
