"""Only Qwen3-4B has a training implementation; GPU validation is pending."""
MODEL_IDS = {f'qwen3-{size}': f'Qwen/Qwen3-{size.upper()}' for size in ('0.6b', '1.7b', '4b', '8b')}
TARGETS = {**{key: 'implemented, GPU validation pending' for key in MODEL_IDS},
           "qwen3.5-bf16": "scaffold only", "gpt-oss-20b": "scaffold only"}


def require_target(config):
    if MODEL_IDS.get(config.target) != config.model_id:
        raise NotImplementedError('Target/model pair must be registered; Qwen3.5 and gpt-oss remain blocked')


def load_training_model(config):
    require_target(config)
    # Unsloth must patch Transformers before Transformers/TRL/PEFT imports.
    from unsloth import FastLanguageModel
    from transformers import AutoTokenizer
    model, _ = FastLanguageModel.from_pretrained(
        model_name=config.model_id, revision=config.revision,
        max_seq_length=config.max_length, dtype=None, load_in_4bit=True,
        trust_remote_code=False, use_exact_model_name=True)
    tokenizer = AutoTokenizer.from_pretrained(config.model_id, revision=config.revision,
                                               trust_remote_code=False)
    if not tokenizer.chat_template:
        raise ValueError("Official tokenizer must supply a chat template")
    model = FastLanguageModel.get_peft_model(
        model, r=config.rank, lora_alpha=config.lora_alpha, lora_dropout=0,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        bias="none", use_gradient_checkpointing="unsloth", random_state=config.seed)
    return model, tokenizer
