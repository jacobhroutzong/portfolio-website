# Tunera modernization audit and delivery plan

## Starting point

This table records the baseline before modernization. See the review evidence
below for the deployed state and GPU results.

| Surface | Verified behavior | Gap or compatibility boundary |
| --- | --- | --- |
| Tunera CPU Space `51595ba` and portfolio workbench | Pinned Qwen3 planner, JSONL validation and seeded split previews, conversation-response scoring, same-origin `/api/tunera` proxy | The public app starts no training. Optional inference in the Space needs a separately configured gateway. Preserve the v1 API and raw workflows. |
| Tunera Python toolkit | Qwen3 0.6B, 1.7B, 4B and 8B use the same QLoRA path. Qwen3-4B is the default. The CLI stages datasets, checkpoints, tracked runs and paired evaluations. | Qwen3 tests exercise mocked GPU training and checkpoint lifecycle. Resume verifies full Trainer state, resolved config, splits, package versions, precision and exact package-source fingerprint. Use the matching archived build to resume an older run. |
| Crucible source `ee94329` | The `modelforge` Hugging Face Space contains the evaluator, fixture suite, tests, and stateless CPU API. The GitHub path named `modelforge` did not resolve with current credentials. | Use the accessible Space source as the reference. Retain the repository and deployed scorer. |
| Portfolio `32efab1` | Tunera and Crucible already have first-party interfaces. Crucible uses `/api/crucible/evaluate`, browser-local reports and notes, and an analytical memory planner. | Keep the standalone app and links active through parity and deployment approval. Existing Space-origin browser records require manual export. |

Tunera evaluates normalized exact text or strict JSON equality against conversation
references. Crucible evaluates an explicit action schema and reports JSON parsing,
schema compliance, exact semantic action success, tool selection, and clarification
precision/recall separately. Semantic success means correct action and arguments;
it uses no model judge. Only `missing` and `compare_runs.run_ids` are order-insensitive.
Unknown IDs fail the request, missing predictions count as case failures, and
undefined ratios remain null. Keep these metrics and labels separate.

Crucible's web case hash is derived from parsed case data with sorted keys while its
CLI hashes the original file bytes. Historical reports retain their original fields.
Matching hashes are the comparison gate for reports with the same hash convention;
when equivalence cannot be established, show separate reports without deltas.

## Stages

1. **Audit and baseline.** Record source revisions, compare evaluator contracts,
   and establish the offline regression baseline. Keep the shipped Qwen3 configuration
   and exact checkpoint rules. Use dedicated local branches for review.
2. **Model experiment.** Pin official Qwen3.5-2B and the experiment runtime, use
   text-only BF16 LoRA and the official template, and require native BF16 CUDA.
   Preserve the Qwen3 default and isolated QLoRA environment. Record the other
   model revisions as candidates. GPU acceptance requires a real smoke train,
   recovery and paired evaluation with measured memory before promotion.
3. **First-party evaluation.** Use the existing Crucible API and scorer from Tunera.
   Add editable examples, JSONL import, separate metrics, failure inspection,
   report export/import, and compatible comparisons. Preserve original report JSON.
   Verify fixture parity and historical report loading before release.
4. **Training workflow.** Add guided planning and dataset preparation with advanced
   JSON workflows. Keep hardware estimates clearly labeled. Expose checkpoint/run
   evidence through imported artifacts when available. Browser tools never start jobs.
5. **Release and retirement.** Verify the native workbench at desktop and mobile sizes.
   Review branches before merging or deploying. Separately approve redirecting
   Crucible's old UI and retiring redundant cards after parity. Preserve repository
   history, the scorer and useful deep links.

## Model roadmap

| Candidate | Official revision | Status |
| --- | --- | --- |
| Qwen3-4B | `1cfa9a7208912126459214e8b04321603b3df60c` | Existing default QLoRA baseline. |
| Qwen3.5-2B | `15852e8c16360a2fea060d615a32b45270f8a8fc` | Experimental BF16 LoRA recipe, GPU-tested on a Colab L4. |
| Qwen3.5-0.8B | `2fc06364715b967f1860aea9cf38778875588b17` | Smaller BF16 candidate. |
| Qwen3.5-4B | `851bf6e806efd8d0a36b00ddf55e13ccb7b8cd0a` | Larger BF16 candidate. |
| Qwen3.5-9B | `c202236235762e1c871ad0ccb60c8ee5ba337b9a` | Requires a suitable BF16 GPU and measured headroom. |
| LFM2-1.2B | Research candidate | Transformers integration and a chat template exist. The LFM Open License v1.0 has redistribution and commercial-use terms. Verify adapter targets and runtime in isolation before use. |

The local RTX 4070 Laptop reported 8,188 MiB of total VRAM. This establishes
device capacity only. Unsloth reports roughly 5 GB for its 2B BF16 LoRA setup;
other runtimes, context lengths, and batch sizes can require more. Record peak
allocated/reserved memory and exact settings during a real run.

## Review evidence

- The Qwen3 package-source fingerprint matches the shipped 0.3.1 archive.
  The default recipe, GPU dependency lock and checkpoint format are preserved.
- The isolated Qwen3.5 CPU contract test used the pinned Transformers and PEFT
  versions, the official tokenizer and a tiny random-weight model. It completed
  two optimizer updates, sealed checkpoints and restored optimizer state from
  step one. It also ran paired baseline and adapter evaluation with shared test
  data. The local laptop attempt stopped at VRAM preflight. The subsequent
  Colab L4 run completed 20 updates and recovered from checkpoint 15 in a fresh
  process. Paired evaluation on four held-out synthetic cases measured 0/4 for
  the base and 4/4 for the recovered adapter. See the
  [experimental recipe and run evidence](QWEN35_EXPERIMENT.md).
- The original Crucible suite passed 32 tests. The deployed scorer matched the
  fixture on metrics, hashes and case failures. The native workbench browser
  tests checked desktop and phone layouts, report import/export, failure
  inspection and comparison gates. These checks use synthetic examples.
- After parity verification and approval, the standalone Crucible portfolio UI
  was retired. Production replay verified all eight redirects to the
  [Evaluation Lab](https://jacobroutzong.dev/projects/tunera/#evaluation-lab),
  historical browser-report recovery, and matching scorer fields. Tunera still
  uses the original scorer API. Its backing Space and history remain in service.

Sources: [Qwen3.5-2B model card](https://huggingface.co/Qwen/Qwen3.5-2B),
[Unsloth fine-tuning guide](https://unsloth.ai/docs/models/qwen3.5/fine-tune),
[Transformers Qwen3.5 API](https://huggingface.co/docs/transformers/v5.13.0/en/model_doc/qwen3_5),
[PEFT LoRA API](https://huggingface.co/docs/peft/main/package_reference/lora), and
[LFM2 model card](https://huggingface.co/LiquidAI/LFM2-1.2B) and its
[license terms](https://huggingface.co/LiquidAI/LFM2-1.2B/blob/main/LICENSE).
