"""Command-line entry points. Network and GPU actions are opt-in commands."""
import argparse
import json
from pathlib import Path
from .artifacts import write_json
from .config import load_config
from .datasets import read_jsonl, save_splits, split_dataset, validate


def parser():
    root = argparse.ArgumentParser(prog="tuneledger")
    sub = root.add_subparsers(dest="command", required=True)
    p = sub.add_parser('doctor')
    p = sub.add_parser('job')
    p.add_argument('action', choices=('status', 'logs', 'cancel'))
    p.add_argument('job_id')
    p.add_argument('--execute', action='store_true')
    p = sub.add_parser('stage-space')
    p.add_argument('--template', default='space')
    p.add_argument('--output', required=True)
    p.add_argument('--comparison')
    p = sub.add_parser('pipeline')
    p.add_argument('--config', required=True)
    p.add_argument('--data', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--smoke', action='store_true')
    p.add_argument('--resume')
    p.add_argument('--execute', action='store_true')
    p = sub.add_parser('runs')
    p.add_argument('root')
    p = sub.add_parser('restore')
    p.add_argument('--repo', required=True)
    p.add_argument('--revision', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--execute', action='store_true')
    p = sub.add_parser('launch')
    p.add_argument('--provider', choices=('local', 'colab', 'hf-jobs'), default='colab')
    p.add_argument('--job-spec')
    p.add_argument('--config')
    p.add_argument('--data')
    p.add_argument('--output')
    p.add_argument('--plan-output')
    p.add_argument('--resume')
    p.add_argument('--smoke', action='store_true')
    p.add_argument('--execute', action='store_true')
    p.add_argument('--approve-cost', action='store_true')
    p = sub.add_parser("validate")
    p.add_argument("data")
    p = sub.add_parser("migrate")
    p.add_argument("source")
    p.add_argument("output")
    p = sub.add_parser("split")
    p.add_argument("data")
    p.add_argument("output")
    p.add_argument("--seed", type=int, default=42)
    p = sub.add_parser("gpu-info")
    p = sub.add_parser("train")
    p.add_argument("--config", required=True)
    p.add_argument("--data", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--resume")
    p.add_argument("--smoke", action="store_true")
    p.add_argument('--checkpoint-repo')
    p.add_argument('--approve-hub-write', action='store_true')
    p = sub.add_parser("evaluate")
    p.add_argument("--config", required=True)
    p.add_argument("--test", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--label", choices=("base", "fine_tuned"), required=True)
    p.add_argument("--adapter")
    p.add_argument("--quantized", action="store_true")
    p.add_argument("--max-new-tokens", type=int, default=128)
    p = sub.add_parser("compare")
    p.add_argument("base")
    p.add_argument("fine_tuned")
    p.add_argument("output")
    p.add_argument("--max-accuracy-drop", type=float, default=0)
    p = sub.add_parser("publish")
    p.add_argument("--run", required=True)
    p.add_argument("--release", required=True)
    p.add_argument("--metadata", required=True)
    p.add_argument("--repo")
    p.add_argument("--upload", action="store_true")
    p.add_argument("--public", action="store_true")
    p = sub.add_parser("export-gguf")
    p.add_argument("--merged-model", required=True)
    p.add_argument("--llama-cpp", required=True)
    p.add_argument("--output", required=True)
    p.add_argument("--enable-export", action="store_true")
    return root


def main(argv=None):
    args = parser().parse_args(argv)
    if args.command == 'doctor':
        from .doctor import doctor
        print(json.dumps(doctor(), indent=2))
    elif args.command == 'job':
        from .runners import HFJobsRunner
        print(json.dumps(HFJobsRunner().manage(args.job_id, args.action, execute=args.execute), indent=2))
    elif args.command == 'stage-space':
        from .deployment import stage_space
        print(stage_space(args.template, args.output, args.comparison))
    elif args.command == 'pipeline':
        from .pipeline import pipeline
        result = pipeline(args.config, args.data, args.output, args.smoke, args.resume, args.execute)
        print(json.dumps(result, indent=2))
        if result.get('status') == 'regression':
            raise SystemExit(1)
    elif args.command == 'runs':
        from .tracking import list_runs
        print(json.dumps(list_runs(args.root), indent=2))
    elif args.command == 'restore':
        from .hub import restore_run
        print(restore_run(args.repo, args.revision, args.output, enabled=args.execute))
    elif args.command == 'launch':
        from .runners import HFJobsRunner, LocalRunner, ColabRunner, local_plan, load_job
        if args.provider == 'hf-jobs':
            if not args.job_spec:
                raise ValueError('HF Jobs requires --job-spec')
            result = HFJobsRunner().submit(load_job(args.job_spec), args.execute, args.approve_cost)
        else:
            if not all((args.config, args.data, args.output)):
                raise ValueError('Local/Colab requires --config, --data and --output')
            plan = local_plan(args.config, args.data, args.output, args.smoke, args.resume)
            plan['provider'] = args.provider
            result = (ColabRunner() if args.provider == 'colab' else LocalRunner()).submit(plan, args.execute)
        if args.plan_output:
            write_json(args.plan_output, result)
        print(json.dumps(result, indent=2))
    elif args.command == "validate":
        print(json.dumps({"valid": True, "count": len(read_jsonl(args.data))}))
    elif args.command == "migrate":
        rows = []
        for i, line in enumerate(Path(args.source).read_text(encoding="utf-8").splitlines()):
            if not line.strip():
                continue
            row = json.loads(line)
            rows.append({"id": f"migrated-{i:06}", "messages": [
                {"role": "user", "content": row["prompt"]},
                {"role": "assistant", "content": row["completion"]}]})
        validate(rows)
        Path(args.output).write_text("".join(json.dumps(r)+"\n" for r in rows), encoding="utf-8")
    elif args.command == "split":
        save_splits(split_dataset(read_jsonl(args.data), args.seed), args.output)
    elif args.command == "gpu-info":
        from .training import gpu_info
        print(json.dumps(gpu_info(), indent=2))
    elif args.command == "train":
        from .training import train
        sync = None
        if args.checkpoint_repo:
            if not args.approve_hub_write:
                raise ValueError('Checkpoint uploads require --approve-hub-write')
            from .hub import sync_run
            def sync(path):
                return sync_run(path, args.checkpoint_repo, enabled=True)
        train(load_config(args.config), args.data, args.output, args.resume, args.smoke, checkpoint_sync=sync)
    elif args.command == "evaluate":
        from .evaluation import evaluate
        from .inference import TransformersAdapter
        config = load_config(args.config)
        import re
        if not re.fullmatch(r"[0-9a-f]{40}", config.revision):
            raise ValueError("Evaluation requires config.resolved.json with an immutable revision")
        if args.max_new_tokens <= 0 or (args.label == "fine_tuned") != bool(args.adapter):
            raise ValueError("fine_tuned requires --adapter; base must omit it; token limit must be positive")
        provenance = {"model_id": config.model_id, "revision": config.revision,
                      "quantized": args.quantized, "adapter": args.adapter, "seed": config.seed}
        rows = read_jsonl(args.test)
        from .evaluation import strict_json
        for row in rows:
            if row.get('scorer') == 'json_exact':
                strict_json(row['messages'][-1]['content'])
        backend = TransformersAdapter(config.model_id, config.revision, args.adapter, args.quantized, config.seed)
        evaluate(backend, rows, args.output, args.label, args.max_new_tokens, provenance)
    elif args.command == "compare":
        from .evaluation import compare
        result = compare(args.base, args.fine_tuned, args.output, args.max_accuracy_drop)
        if not result["regression_pass"]:
            raise SystemExit(1)
    elif args.command == "publish":
        from .publishing import stage_release, upload
        if args.upload and not args.repo:
            raise ValueError("--repo is required for upload")
        stage_release(args.run, args.release, json.loads(Path(args.metadata).read_text()))
        if args.upload:
            upload(args.release, args.repo, enabled=True, private=not args.public)
    elif args.command == "export-gguf":
        from .export import export_gguf
        export_gguf(args.merged_model, args.llama_cpp, args.output, args.enable_export)


if __name__ == "__main__":
    main()
