"""CPU-only UI; user-configured inference gateway may be offline."""
import json
import os
import urllib.error
import urllib.request
from pathlib import Path
import gradio as gr
from demo_core import EXAMPLES, REVISIONS, plan_run, validate_data, score_outputs


def respond(message, history):
    endpoint = os.environ.get("TUNELEDGER_ENDPOINT")
    model = os.environ.get("TUNELEDGER_OLLAMA_MODEL")
    if not endpoint or not model:
        return "Inference is unavailable. Configure a model endpoint when compute is available."
    if len(message) > 8000:
        return "Please limit your message to 8,000 characters."
    payload = {"model": model, "messages": [{"role": "user", "content": message}], "stream": False,
               "think": False, "options": {"temperature": 0, "seed": 42, "num_predict": 128}}
    headers = {"Content-Type": "application/json"}
    if os.environ.get("TUNELEDGER_ENDPOINT_TOKEN"):
        headers["Authorization"] = "Bearer " + os.environ["TUNELEDGER_ENDPOINT_TOKEN"]
    try:
        req = urllib.request.Request(endpoint.rstrip("/")+"/api/chat", json.dumps(payload).encode(), headers)
        with urllib.request.urlopen(req, timeout=90) as response:
            return json.load(response)["message"]["content"]
    except (urllib.error.URLError, TimeoutError, ValueError, KeyError):
        return "Inference is currently unavailable. Try again when the configured compute is online."


ASSETS = Path(__file__).parent
with gr.Blocks(title='Tunera', css='.parameter-control .prose p { color: var(--body-text-color); line-height: 1.55; }') as demo:
    mark = (ASSETS / 'brand.svg').read_text(encoding='utf-8')
    gr.HTML('<div style="display:flex;align-items:center;gap:16px;margin-bottom:12px">' + mark +
            '<h1 style="font-size:32px;line-height:1.2;margin:0">Tunera</h1></div>')
    gr.Markdown('Prepare a Qwen3 fine-tuning run, check your dataset, or score responses you already have. '
                '**This demo runs on CPU. It does not train or run a model.**\n\n'
                '[What the settings mean](https://jacobroutzong.dev/projects/tunera/#what-the-settings-mean) · '
                '[Download source](https://jacobroutzong.dev/downloads/tunera-ai-0.3.1.zip)')
    tool_marks = []
    for slug, label in [('python', 'Python'), ('pytorch', 'PyTorch'), ('huggingface', 'Hugging Face'), ('googlecolab', 'Colab')]:
        icon = (ASSETS / 'logos' / f'{slug}.svg').read_text(encoding='utf-8').replace('<svg ', '<svg width="20" height="20" ', 1)
        tool_marks.append('<span style="display:inline-flex;align-items:center;gap:7px">' + icon + label + '</span>')
    gr.HTML('<div style="display:flex;flex-wrap:wrap;gap:12px 22px;font-size:13px;margin-bottom:12px">' + ''.join(tool_marks) + '</div>')
    with gr.Tab('Plan an experiment'):
        gr.Markdown('Choose the model and training settings, then select **Build plan**. This creates a configuration; it starts no job.')
        with gr.Row():
            size = gr.Dropdown(list(REVISIONS), value='4B', label='Qwen3 model size', elem_classes=['parameter-control'],
                               info='4B means about four billion weights in the base model. Larger models generally need more GPU memory.')
            context = gr.Slider(128, 4096, value=512, step=128, label='Maximum context tokens', elem_classes=['parameter-control'],
                                info='The prompt and answer must fit within this limit. Tokens are pieces of text, not necessarily whole words. Longer examples need more memory.')
        with gr.Row():
            rank = gr.Slider(4, 64, value=16, step=4, label='LoRA rank', elem_classes=['parameter-control'],
                             info='Sets the size of the trainable adapter matrices. Higher ranks add capacity and memory use; they do not guarantee better results.')
            steps = gr.Slider(2, 1000, value=100, step=1, label='Optimizer steps', elem_classes=['parameter-control'],
                              info='How many times the optimizer updates the adapter weights. This is not the number of unique examples or passes through the dataset.')
        plan = gr.JSON(value=plan_run('4B', 512, 16, 100), label='Experiment plan')
        gr.Button('Build plan', variant='primary').click(plan_run, [size, context, rank, steps], plan)
    with gr.Tab('Validate a dataset'):
        gr.Markdown('Use public or synthetic examples only. This shared demo processes inputs on the Space server. '
                    'Limit: 250 cases / 256 KB. Source grouping and normalized duplicate checks do not detect semantic paraphrases.')
        cases = gr.Textbox(value=EXAMPLES, lines=12, label='Conversation cases (JSONL)')
        validation = gr.JSON(label='Validation and seeded split preview')
        gr.Button('Validate data', variant='primary').click(validate_data, cases, validation)
    with gr.Tab('Score saved outputs'):
        gr.Markdown('Scores supplied text against reference cases. This performs no inference; these are not measured model benchmarks.')
        scoring_cases = gr.Textbox(value=EXAMPLES, lines=7, label='Reference cases (JSONL)')
        saved_outputs = gr.Textbox(lines=6, label='Predictions: JSON object mapping case IDs to response strings',
                                  placeholder='{"case-01": "{\\"result\\": 3}", ...}')
        scores = gr.JSON(label='Case-level report')
        gr.Button('Score outputs', variant='primary').click(score_outputs, [scoring_cases, saved_outputs], scores)
    with gr.Tab('Evaluation'):
        results = Path(__file__).parent / 'benchmarks.json'
        gr.JSON(json.loads(results.read_text(encoding='utf-8')) if results.exists()
                else {'status': 'No measured GPU benchmark results available'})
    with gr.Tab('Optional inference'):
        gr.ChatInterface(respond, type="messages", title="Configured model gateway",
            description="Unavailable until a separate inference gateway is configured. Requests are independent.")
if __name__ == "__main__":
    demo.queue(default_concurrency_limit=1, max_size=8).launch()
